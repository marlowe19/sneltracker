(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_8dd04c61._.js",
  "static/chunks/node_modules_8a8a9c12._.js"
],
    source: "dynamic"
});
