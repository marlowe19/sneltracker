(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/stores/useStore.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStore",
    ()=>useStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
;
;
const useStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devtools"])((set, get)=>({
        // ========== Entries State ==========
        entries: [],
        activeEntries: [],
        stoppedTimers: [],
        loadingEntries: false,
        entriesError: null,
        weekOffset: 0,
        // ========== Projects State ==========
        projects: [],
        loadingProjects: false,
        projectsError: null,
        // ========== Expenses State ==========
        expenses: [],
        loadingExpenses: false,
        expensesError: null,
        weekExpenses: [],
        loadingWeekExpenses: false,
        weekExpensesError: null,
        // ========== UI State ==========
        openDropdowns: {},
        stoppedTimers: {},
        pendingTimers: [],
        // ========== Entries Actions ==========
        // Hydrate active entries from server (initial load)
        hydrateActiveEntries: (serverActiveEntries)=>{
            set({
                activeEntries: serverActiveEntries
            });
        },
        // Hydrate stopped timers from server (initial load)
        hydrateStoppedTimers: (serverStoppedTimers)=>{
            set({
                stoppedTimers: serverStoppedTimers
            });
        },
        // Fetch week entries client-side
        fetchWeekEntries: async (user, weekStart, weekEnd)=>{
            set({
                loadingEntries: true,
                entriesError: null
            });
            try {
                const res = await fetch(`/${encodeURIComponent(user)}/api/week-entries?weekStart=${weekStart}&weekEnd=${weekEnd}`);
                if (!res.ok) throw new Error("Failed to fetch week entries");
                const data = await res.json();
                set({
                    entries: data.entries,
                    loadingEntries: false
                });
            } catch (error) {
                set({
                    entriesError: error.message,
                    loadingEntries: false
                });
            }
        },
        // Update week offset
        setWeekOffset: (offset)=>set({
                weekOffset: offset
            }),
        // Optimistic updates for entries
        addEntry: (newEntry)=>{
            set((state)=>{
                // If entry already has an ID, use it (e.g., stopped timers)
                // Otherwise, add a temp ID for new entries
                const entryWithId = newEntry.id ? newEntry : {
                    ...newEntry,
                    id: `temp-${Date.now()}`
                };
                // Check if entry with this ID already exists to avoid duplicates
                const existingIndex = state.entries.findIndex((e)=>e.id === entryWithId.id);
                if (existingIndex !== -1) {
                    // Update existing entry
                    const updatedEntries = [
                        ...state.entries
                    ];
                    updatedEntries[existingIndex] = entryWithId;
                    return {
                        entries: updatedEntries
                    };
                } else {
                    // Add new entry
                    return {
                        entries: [
                            ...state.entries,
                            entryWithId
                        ]
                    };
                }
            });
        },
        updateEntry: (entryId, updates)=>{
            set((state)=>({
                    entries: state.entries.map((entry)=>entry.id === entryId ? {
                            ...entry,
                            ...updates
                        } : entry),
                    // Also update activeEntries if it's an active entry
                    activeEntries: state.activeEntries.map((entry)=>entry.id === entryId ? {
                            ...entry,
                            ...updates
                        } : entry)
                }));
        },
        replaceTempEntry: (tempId, realEntry)=>{
            set((state)=>{
                const entryIndex = state.entries.findIndex((entry)=>entry.id === tempId);
                if (entryIndex !== -1) {
                    // Replace temp entry with real entry
                    const newEntries = [
                        ...state.entries
                    ];
                    newEntries[entryIndex] = realEntry;
                    return {
                        entries: newEntries
                    };
                } else {
                    // Temp entry not found, add the real entry to the array
                    return {
                        entries: [
                            ...state.entries,
                            realEntry
                        ]
                    };
                }
            });
        },
        deleteEntry: (entryId)=>{
            set((state)=>({
                    entries: state.entries.filter((entry)=>entry.id !== entryId),
                    activeEntries: state.activeEntries.filter((entry)=>entry.id !== entryId)
                }));
        },
        // Update active entries (for when timers start/stop)
        updateActiveEntries: (entries)=>{
            set({
                activeEntries: entries
            });
        },
        // ========== Projects Actions ==========
        // Hydrate projects from server (initial load)
        hydrateProjects: (serverProjects)=>{
            set({
                projects: serverProjects || []
            });
        },
        fetchProjects: async (user)=>{
            const currentState = get();
            // Prevent concurrent fetches
            if (currentState.loadingProjects) {
                return;
            }
            set({
                loadingProjects: true,
                projectsError: null
            });
            try {
                const res = await fetch(`/${encodeURIComponent(user)}/projecten/api`);
                if (!res.ok) throw new Error("Failed to fetch projects");
                const data = await res.json();
                set({
                    projects: data.projects || [],
                    loadingProjects: false
                });
            } catch (error) {
                set({
                    projectsError: error.message,
                    loadingProjects: false
                });
            }
        },
        addProject: (project)=>{
            set((state)=>({
                    projects: [
                        ...state.projects,
                        project
                    ]
                }));
        },
        updateProject: (projectId, updates)=>{
            set((state)=>({
                    projects: state.projects.map((p)=>p.id === projectId ? {
                            ...p,
                            ...updates
                        } : p)
                }));
        },
        deleteProject: (projectId)=>{
            set((state)=>({
                    projects: state.projects.filter((p)=>p.id !== projectId)
                }));
        },
        // ========== Expenses Actions ==========
        fetchDayExpenses: async (user, dayDate)=>{
            const currentState = get();
            // Prevent concurrent fetches
            if (currentState.loadingExpenses) {
                return;
            }
            set({
                loadingExpenses: true,
                expensesError: null
            });
            try {
                const res = await fetch(`/${encodeURIComponent(user)}/api/day-expenses?dayDate=${dayDate.toISOString()}`);
                if (!res.ok) throw new Error("Failed to fetch day expenses");
                const data = await res.json();
                set({
                    expenses: data.expenses || [],
                    loadingExpenses: false
                });
            } catch (error) {
                set({
                    expensesError: error.message,
                    loadingExpenses: false
                });
            }
        },
        fetchWeekExpenses: async (user, weekStart, weekEnd)=>{
            const currentState = get();
            // Prevent concurrent fetches
            if (currentState.loadingWeekExpenses) {
                return;
            }
            set({
                loadingWeekExpenses: true,
                weekExpensesError: null
            });
            try {
                const res = await fetch(`/${encodeURIComponent(user)}/expenses?weekStart=${weekStart}&weekEnd=${weekEnd}`);
                if (!res.ok) throw new Error("Failed to fetch week expenses");
                const data = await res.json();
                set({
                    weekExpenses: data.expenses || [],
                    loadingWeekExpenses: false
                });
            } catch (error) {
                set({
                    weekExpensesError: error.message,
                    loadingWeekExpenses: false
                });
            }
        },
        addExpense: (newExpense)=>{
            const tempId = `temp-${Date.now()}`;
            set((state)=>({
                    expenses: [
                        ...state.expenses,
                        {
                            ...newExpense,
                            id: tempId
                        }
                    ],
                    weekExpenses: [
                        ...state.weekExpenses,
                        {
                            ...newExpense,
                            id: tempId
                        }
                    ]
                }));
        },
        updateExpense: (expenseId, updates)=>{
            set((state)=>({
                    expenses: state.expenses.map((expense)=>expense.id === expenseId ? {
                            ...expense,
                            ...updates
                        } : expense),
                    weekExpenses: state.weekExpenses.map((expense)=>expense.id === expenseId ? {
                            ...expense,
                            ...updates
                        } : expense)
                }));
        },
        replaceTempExpense: (tempId, realExpense)=>{
            set((state)=>{
                const expenseIndex = state.expenses.findIndex((expense)=>expense.id === tempId);
                const weekExpenseIndex = state.weekExpenses.findIndex((expense)=>expense.id === tempId);
                let newExpenses = state.expenses;
                let newWeekExpenses = state.weekExpenses;
                if (expenseIndex !== -1) {
                    newExpenses = [
                        ...state.expenses
                    ];
                    newExpenses[expenseIndex] = realExpense;
                } else {
                    newExpenses = [
                        ...state.expenses,
                        realExpense
                    ];
                }
                if (weekExpenseIndex !== -1) {
                    newWeekExpenses = [
                        ...state.weekExpenses
                    ];
                    newWeekExpenses[weekExpenseIndex] = realExpense;
                } else {
                    newWeekExpenses = [
                        ...state.weekExpenses,
                        realExpense
                    ];
                }
                return {
                    expenses: newExpenses,
                    weekExpenses: newWeekExpenses
                };
            });
        },
        deleteExpense: (expenseId)=>{
            set((state)=>({
                    expenses: state.expenses.filter((expense)=>expense.id !== expenseId),
                    weekExpenses: state.weekExpenses.filter((expense)=>expense.id !== expenseId)
                }));
        },
        // ========== UI Actions ==========
        toggleDropdown: (timerId)=>{
            set((state)=>({
                    openDropdowns: {
                        ...state.openDropdowns,
                        [timerId]: !state.openDropdowns[timerId]
                    }
                }));
        },
        closeDropdown: (timerId)=>{
            set((state)=>({
                    openDropdowns: {
                        ...state.openDropdowns,
                        [timerId]: false
                    }
                }));
        },
        setStoppedTimer: (entryId, stopTime)=>{
            set((state)=>({
                    stoppedTimers: {
                        ...state.stoppedTimers,
                        [entryId]: stopTime
                    }
                }));
        },
        addPendingTimer: (timer)=>{
            set((state)=>({
                    pendingTimers: [
                        ...state.pendingTimers,
                        timer
                    ]
                }));
        },
        removePendingTimer: (timerId)=>{
            set((state)=>({
                    pendingTimers: state.pendingTimers.filter((t)=>t.id !== timerId)
                }));
        },
        updatePendingTimer: (timerId, updates)=>{
            set((state)=>({
                    pendingTimers: state.pendingTimers.map((t)=>t.id === timerId ? {
                            ...t,
                            ...updates
                        } : t)
                }));
        },
        clearPendingTimers: ()=>{
            set({
                pendingTimers: []
            });
        }
    }), {
    name: "AppStore"
}));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[user]/HeaderSectionClient.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeaderSectionClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
"use client";
;
;
function HeaderSectionClient(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "50561eb72ee8c5b8787fff56986039fe0d45a7c3e9b888cb7c97b13b24a0c992") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "50561eb72ee8c5b8787fff56986039fe0d45a7c3e9b888cb7c97b13b24a0c992";
    }
    const { user, onAddTimer } = t0;
    let t1;
    if ($[1] !== user) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-left text-lg font-semibold",
            children: [
                "Hi",
                " ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-gray-700 inline-block capitalize",
                    children: [
                        user,
                        ","
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/[user]/HeaderSectionClient.js",
                    lineNumber: 18,
                    columnNumber: 65
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/[user]/HeaderSectionClient.js",
            lineNumber: 18,
            columnNumber: 10
        }, this);
        $[1] = user;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "3",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            "aria-hidden": "true",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                    x1: "12",
                    y1: "5",
                    x2: "12",
                    y2: "19"
                }, void 0, false, {
                    fileName: "[project]/app/[user]/HeaderSectionClient.js",
                    lineNumber: 27,
                    columnNumber: 172
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                    x1: "5",
                    y1: "12",
                    x2: "19",
                    y2: "12"
                }, void 0, false, {
                    fileName: "[project]/app/[user]/HeaderSectionClient.js",
                    lineNumber: 27,
                    columnNumber: 211
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/[user]/HeaderSectionClient.js",
            lineNumber: 27,
            columnNumber: 10
        }, this);
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            children: "Timer toevoegen"
        }, void 0, false, {
            fileName: "[project]/app/[user]/HeaderSectionClient.js",
            lineNumber: 28,
            columnNumber: 10
        }, this);
        $[3] = t2;
        $[4] = t3;
    } else {
        t2 = $[3];
        t3 = $[4];
    }
    let t4;
    if ($[5] !== onAddTimer) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: onAddTimer,
            className: "btn px-4 py-3 text-base rounded-lg flex items-center gap-2 min-h-[48px] bg-[#0F766E]!",
            "aria-label": "Timer toevoegen",
            children: [
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/app/[user]/HeaderSectionClient.js",
            lineNumber: 37,
            columnNumber: 10
        }, this);
        $[5] = onAddTimer;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== t1 || $[8] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "p-4 flex items-center justify-between",
            children: [
                t1,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/app/[user]/HeaderSectionClient.js",
            lineNumber: 45,
            columnNumber: 10
        }, this);
        $[7] = t1;
        $[8] = t4;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    return t5;
}
_c = HeaderSectionClient;
var _c;
__turbopack_context__.k.register(_c, "HeaderSectionClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/time.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "computeEntryDurationMs",
    ()=>computeEntryDurationMs,
    "computeEntryDurationMsClipped",
    ()=>computeEntryDurationMsClipped,
    "daysBetween",
    ()=>daysBetween,
    "floorTo15Minutes",
    ()=>floorTo15Minutes,
    "formatHM",
    ()=>formatHM,
    "formatHMS",
    ()=>formatHMS,
    "getMonthBounds",
    ()=>getMonthBounds,
    "getQuarterBounds",
    ()=>getQuarterBounds,
    "getWeekBounds",
    ()=>getWeekBounds,
    "roundDurationTo15Minutes",
    ()=>roundDurationTo15Minutes,
    "toIso",
    ()=>toIso
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$startOfWeek$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/startOfWeek.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$endOfWeek$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/endOfWeek.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$startOfMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/startOfMonth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$endOfMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/endOfMonth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$startOfQuarter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/startOfQuarter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$endOfQuarter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/endOfQuarter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/parseISO.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInMilliseconds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/differenceInMilliseconds.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$addMilliseconds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/addMilliseconds.js [app-client] (ecmascript)");
;
function getWeekBounds(date = new Date()) {
    const start = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$startOfWeek$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startOfWeek"])(date, {
        weekStartsOn: 1
    }); // Monday
    const end = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$endOfWeek$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endOfWeek"])(date, {
        weekStartsOn: 1
    });
    return {
        start,
        end
    };
}
function getMonthBounds(date = new Date()) {
    const start = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$startOfMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startOfMonth"])(date);
    const end = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$endOfMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endOfMonth"])(date);
    return {
        start,
        end
    };
}
function getQuarterBounds(date = new Date()) {
    const start = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$startOfQuarter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startOfQuarter"])(date);
    const end = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$endOfQuarter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endOfQuarter"])(date);
    return {
        start,
        end
    };
}
function toIso(d) {
    return new Date(d).toISOString();
}
function roundDurationTo15Minutes(ms) {
    const fifteen = 15 * 60 * 1000;
    return Math.round(ms / fifteen) * fifteen;
}
function floorTo15Minutes(ms) {
    const fifteen = 15 * 60 * 1000;
    return Math.floor(ms / fifteen) * fifteen;
}
function computeEntryDurationMs(startIso, endIso, durationMs = null) {
    // If duration_ms is provided, use it directly
    if (durationMs !== null && durationMs !== undefined) {
        return durationMs;
    }
    // Otherwise calculate from start/end times
    const start = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseISO"])(startIso);
    const end = endIso ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseISO"])(endIso) : new Date();
    return Math.max(0, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInMilliseconds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["differenceInMilliseconds"])(end, start));
}
function computeEntryDurationMsClipped(startIso, endIso, rangeStart, rangeEnd, durationMs = null) {
    // If duration_ms is provided, use it directly (assume it's for the day it's assigned to)
    if (durationMs !== null && durationMs !== undefined) {
        // Check if the entry's day falls within the range
        const entryStart = startIso ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseISO"])(startIso) : new Date(rangeStart);
        const entryDay = new Date(entryStart);
        entryDay.setHours(0, 0, 0, 0);
        // If entry day is within the range, return full duration_ms
        if (entryDay >= rangeStart && entryDay < rangeEnd) {
            return durationMs;
        }
        return 0;
    }
    // Otherwise calculate from start/end times with clipping
    const entryStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseISO"])(startIso);
    const entryEnd = endIso ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseISO"])(endIso) : new Date();
    // Calculate the clipped boundaries
    const clippedStart = entryStart > rangeStart ? entryStart : rangeStart;
    const clippedEnd = entryEnd < rangeEnd ? entryEnd : rangeEnd;
    // Ensure clipped start is before clipped end
    if (clippedStart >= clippedEnd) return 0;
    return Math.max(0, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInMilliseconds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["differenceInMilliseconds"])(clippedEnd, clippedStart));
}
function formatHMS(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600).toString().padStart(2, "0");
    const minutes = Math.floor(totalSeconds % 3600 / 60).toString().padStart(2, "0");
    const seconds = (totalSeconds % 60).toString().padStart(2, "0");
    return `${hours}:${minutes}:${seconds}`;
}
function formatHM(ms) {
    const totalMinutes = Math.floor(ms / 60000);
    const hours = Math.floor(totalMinutes / 60).toString().padStart(2, "0");
    const minutes = (totalMinutes % 60).toString().padStart(2, "0");
    return `${hours}:${minutes}`;
}
function daysBetween(start, end) {
    const days = [];
    const dayMs = 24 * 60 * 60 * 1000;
    let current = new Date(start);
    const endTime = new Date(end).getTime();
    while(current.getTime() <= endTime){
        days.push(new Date(current));
        current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$addMilliseconds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addMilliseconds"])(current, dayMs);
    }
    return days;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[user]/RunningClockClient.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RunningClockClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/time.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function RunningClockClient(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "288e8dea51bd6e4e3bf472a78f4fec67df092cb70d29f1e1c165e04a58b0cf17") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "288e8dea51bd6e4e3bf472a78f4fec67df092cb70d29f1e1c165e04a58b0cf17";
    }
    const { startedAt, stoppedAt } = t0;
    let t1;
    if ($[1] !== startedAt) {
        t1 = startedAt ? new Date(startedAt).getTime() : null;
        $[1] = startedAt;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const startMs = t1;
    let t2;
    if ($[3] !== stoppedAt) {
        t2 = stoppedAt ? new Date(stoppedAt).getTime() : null;
        $[3] = stoppedAt;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const stopMs = t2;
    const [now, setNow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(_RunningClockClientUseState);
    let t3;
    let t4;
    if ($[5] !== startMs || $[6] !== stopMs) {
        t3 = ({
            "RunningClockClient[useEffect()]": ()=>{
                if (!startMs || stopMs) {
                    return;
                }
                setNow(Date.now());
                const id = setInterval({
                    "RunningClockClient[useEffect() > setInterval()]": ()=>setNow(Date.now())
                }["RunningClockClient[useEffect() > setInterval()]"], 1000);
                return ()=>clearInterval(id);
            }
        })["RunningClockClient[useEffect()]"];
        t4 = [
            startMs,
            stopMs
        ];
        $[5] = startMs;
        $[6] = stopMs;
        $[7] = t3;
        $[8] = t4;
    } else {
        t3 = $[7];
        t4 = $[8];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    const isRunning = startMs && !stopMs;
    const currentTime = stopMs || now;
    const elapsed = startMs ? Math.max(0, currentTime - startMs) : 0;
    let t5;
    if ($[9] !== elapsed) {
        const formatted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatHM"])(elapsed);
        t5 = formatted.split(":");
        $[9] = elapsed;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    const [hours, minutes] = t5;
    if (!startMs) {
        let t6;
        if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "timer-text",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "00"
                    }, void 0, false, {
                        fileName: "[project]/app/[user]/RunningClockClient.js",
                        lineNumber: 78,
                        columnNumber: 41
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "timer-colon",
                        children: ":"
                    }, void 0, false, {
                        fileName: "[project]/app/[user]/RunningClockClient.js",
                        lineNumber: 78,
                        columnNumber: 56
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "00"
                    }, void 0, false, {
                        fileName: "[project]/app/[user]/RunningClockClient.js",
                        lineNumber: 78,
                        columnNumber: 94
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/[user]/RunningClockClient.js",
                lineNumber: 78,
                columnNumber: 12
            }, this);
            $[11] = t6;
        } else {
            t6 = $[11];
        }
        return t6;
    }
    let t6;
    if ($[12] !== hours) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            children: hours
        }, void 0, false, {
            fileName: "[project]/app/[user]/RunningClockClient.js",
            lineNumber: 87,
            columnNumber: 10
        }, this);
        $[12] = hours;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    const t7 = `timer-colon ${isRunning ? "blink" : ""}`;
    let t8;
    if ($[14] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: t7,
            children: ":"
        }, void 0, false, {
            fileName: "[project]/app/[user]/RunningClockClient.js",
            lineNumber: 96,
            columnNumber: 10
        }, this);
        $[14] = t7;
        $[15] = t8;
    } else {
        t8 = $[15];
    }
    let t9;
    if ($[16] !== minutes) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            children: minutes
        }, void 0, false, {
            fileName: "[project]/app/[user]/RunningClockClient.js",
            lineNumber: 104,
            columnNumber: 10
        }, this);
        $[16] = minutes;
        $[17] = t9;
    } else {
        t9 = $[17];
    }
    let t10;
    if ($[18] !== t6 || $[19] !== t8 || $[20] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "timer-text",
            children: [
                t6,
                t8,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/app/[user]/RunningClockClient.js",
            lineNumber: 112,
            columnNumber: 11
        }, this);
        $[18] = t6;
        $[19] = t8;
        $[20] = t9;
        $[21] = t10;
    } else {
        t10 = $[21];
    }
    return t10;
}
_s(RunningClockClient, "hRsg5VqdEFon1R+uPVzq5poKYFY=");
_c = RunningClockClient;
function _RunningClockClientUseState() {
    return Date.now();
}
var _c;
__turbopack_context__.k.register(_c, "RunningClockClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[user]/MoneyCounterClient.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MoneyCounterClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function MoneyCounterClient(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "bbc1820e45741fe662edfc86988efa5f0168b26b5e1d84c0509e584de5c176a8") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "bbc1820e45741fe662edfc86988efa5f0168b26b5e1d84c0509e584de5c176a8";
    }
    const { startedAt, hourlyRate, stoppedAt } = t0;
    let t1;
    if ($[1] !== startedAt) {
        t1 = startedAt ? new Date(startedAt).getTime() : null;
        $[1] = startedAt;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const startMs = t1;
    let t2;
    if ($[3] !== stoppedAt) {
        t2 = stoppedAt ? new Date(stoppedAt).getTime() : null;
        $[3] = stoppedAt;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const stopMs = t2;
    const [now, setNow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(_MoneyCounterClientUseState);
    let t3;
    let t4;
    if ($[5] !== startMs || $[6] !== stopMs) {
        t3 = ({
            "MoneyCounterClient[useEffect()]": ()=>{
                if (!startMs) {
                    return;
                }
                const id = setInterval({
                    "MoneyCounterClient[useEffect() > setInterval()]": ()=>{
                        if (!stopMs) {
                            setNow(Date.now());
                        }
                    }
                }["MoneyCounterClient[useEffect() > setInterval()]"], 60000);
                return ()=>clearInterval(id);
            }
        })["MoneyCounterClient[useEffect()]"];
        t4 = [
            startMs,
            stopMs
        ];
        $[5] = startMs;
        $[6] = stopMs;
        $[7] = t3;
        $[8] = t4;
    } else {
        t3 = $[7];
        t4 = $[8];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    if (!startMs || !hourlyRate) {
        return null;
    }
    const currentTime = stopMs || now;
    const elapsed = currentTime - startMs;
    const elapsedMinutes = Math.floor(elapsed / 60000);
    const elapsedMs = elapsedMinutes * 60000;
    const hours = elapsedMs / 3600000;
    const money = hours * hourlyRate;
    let t5;
    if ($[9] !== money) {
        t5 = new Intl.NumberFormat("nl-NL", {
            style: "currency",
            currency: "EUR",
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(money);
        $[9] = money;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    const formattedMoney = t5;
    let t6;
    if ($[11] !== formattedMoney) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "money-text",
            children: formattedMoney
        }, void 0, false, {
            fileName: "[project]/app/[user]/MoneyCounterClient.js",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[11] = formattedMoney;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    return t6;
}
_s(MoneyCounterClient, "9wUFgSocf05w/AGgVfBO9vXWTk4=");
_c = MoneyCounterClient;
function _MoneyCounterClientUseState() {
    return Date.now();
}
var _c;
__turbopack_context__.k.register(_c, "MoneyCounterClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[user]/TimerSectionClient.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TimerSectionClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/stores/useStore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$RunningClockClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/[user]/RunningClockClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$MoneyCounterClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/[user]/MoneyCounterClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/time.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function TimerSectionClient({ user }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [isPending, startTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"])();
    const activeEntries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[activeEntries]": (state)=>state.activeEntries
    }["TimerSectionClient.useStore[activeEntries]"]);
    const stoppedTimersList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[stoppedTimersList]": (state_0)=>state_0.stoppedTimers
    }["TimerSectionClient.useStore[stoppedTimersList]"]);
    const projects = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[projects]": (state_1)=>state_1.projects
    }["TimerSectionClient.useStore[projects]"]);
    const openDropdowns = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[openDropdowns]": (state_2)=>state_2.openDropdowns
    }["TimerSectionClient.useStore[openDropdowns]"]);
    const stoppedTimers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[stoppedTimers]": (state_3)=>state_3.stoppedTimers
    }["TimerSectionClient.useStore[stoppedTimers]"]);
    const pendingTimers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[pendingTimers]": (state_4)=>state_4.pendingTimers
    }["TimerSectionClient.useStore[pendingTimers]"]);
    const toggleDropdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[toggleDropdown]": (state_5)=>state_5.toggleDropdown
    }["TimerSectionClient.useStore[toggleDropdown]"]);
    const closeDropdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[closeDropdown]": (state_6)=>state_6.closeDropdown
    }["TimerSectionClient.useStore[closeDropdown]"]);
    const setStoppedTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[setStoppedTimer]": (state_7)=>state_7.setStoppedTimer
    }["TimerSectionClient.useStore[setStoppedTimer]"]);
    const removePendingTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[removePendingTimer]": (state_8)=>state_8.removePendingTimer
    }["TimerSectionClient.useStore[removePendingTimer]"]);
    const updatePendingTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[updatePendingTimer]": (state_9)=>state_9.updatePendingTimer
    }["TimerSectionClient.useStore[updatePendingTimer]"]);
    const addEntry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[addEntry]": (state_10)=>state_10.addEntry
    }["TimerSectionClient.useStore[addEntry]"]);
    const updateActiveEntries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "TimerSectionClient.useStore[updateActiveEntries]": (state_11)=>state_11.updateActiveEntries
    }["TimerSectionClient.useStore[updateActiveEntries]"]);
    const dropdownRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({}); // timerId -> ref
    // Click outside handler to close dropdowns
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TimerSectionClient.useEffect": ()=>{
            function handleClickOutside(event) {
                Object.keys(openDropdowns).forEach({
                    "TimerSectionClient.useEffect.handleClickOutside": (timerId)=>{
                        if (openDropdowns[timerId] && dropdownRefs.current[timerId]) {
                            if (!dropdownRefs.current[timerId].contains(event.target)) {
                                closeDropdown(timerId);
                            }
                        }
                    }
                }["TimerSectionClient.useEffect.handleClickOutside"]);
            }
            if (Object.values(openDropdowns).some(Boolean)) {
                document.addEventListener("mousedown", handleClickOutside);
                return ({
                    "TimerSectionClient.useEffect": ()=>{
                        document.removeEventListener("mousedown", handleClickOutside);
                    }
                })["TimerSectionClient.useEffect"];
            }
        }
    }["TimerSectionClient.useEffect"], [
        openDropdowns,
        closeDropdown
    ]);
    function handleProjectChange(entryId, newProjectId) {
        closeDropdown(entryId);
        if (entryId.startsWith("pending-")) {
            // Update pending timer
            updatePendingTimer(entryId, {
                projectId: newProjectId
            });
        } else {
            // Update active entry
            async function updateEntryProject() {
                try {
                    const res = await fetch(`/${encodeURIComponent(user)}/entries/${entryId}`, {
                        method: "PATCH",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            project: newProjectId || null
                        })
                    });
                    if (res.ok) {
                        startTransition(()=>router.refresh());
                    }
                } catch (error) {
                    console.error("Error updating entry project:", error);
                }
            }
            updateEntryProject();
        }
    }
    async function handleStart(timer) {
        try {
            const url = new URL(`/${encodeURIComponent(user)}/start`, window.location.origin);
            if (timer.projectId) {
                url.searchParams.set("project", timer.projectId);
            }
            await fetch(url.toString(), {
                method: "POST"
            });
            // Remove from pending
            removePendingTimer(timer.id);
            startTransition(()=>router.refresh());
        } catch (error_0) {
            console.error("Error starting timer:", error_0);
        }
    }
    async function handleStop(entry) {
        const stopTime = new Date().toISOString();
        setStoppedTimer(entry.id, stopTime);
        try {
            const response = await fetch(`/${encodeURIComponent(user)}/stop`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    entryId: entry.id
                })
            });
            if (response.ok) {
                const data = await response.json();
                // The stopped entry is now in the database with end_time set
                // Create a stopped entry object from the current entry + stop time
                const stoppedEntry = {
                    ...entry,
                    end_time: data.endedAt || stopTime,
                    is_running: false,
                    duration_ms: data.durationMs || null
                };
                // Add to entries store immediately so it appears in day modal
                addEntry(stoppedEntry);
                // Remove from activeEntries immediately
                updateActiveEntries(activeEntries.filter((e)=>e.id !== entry.id));
            }
            startTransition(()=>router.refresh());
        } catch (error_1) {
            console.error("Error stopping timer:", error_1);
        }
    }
    const allTimers = [
        ...activeEntries.map((entry_0)=>({
                type: "active",
                data: entry_0
            })),
        ...pendingTimers.map((timer_0)=>({
                type: "pending",
                data: timer_0
            }))
    ];
    const renderTimer = (timer_1)=>{
        const entry_1 = timer_1.type === "active" ? timer_1.data : null;
        const pending = timer_1.type === "pending" ? timer_1.data : null;
        const timerId_0 = entry_1?.id || pending?.id;
        const isPendingTimer = timer_1.type === "pending";
        const stoppedAt = stoppedTimers[timerId_0];
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "timer-box flex flex-row items-center pl-4 pr-4 pt-2 pb-2 rounded-lg mb-4 bg-white",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col flex-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            ref: (el)=>{
                                dropdownRefs.current[timerId_0] = el;
                            },
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>toggleDropdown(timerId_0),
                                    className: " py-2 text-base text-gray-700 flex items-center gap-2 min-w-[200px]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-1.5 flex-1 text-left",
                                            children: (()=>{
                                                const selectedProjectId = entry_1?.project || pending?.projectId || "";
                                                const selectedProject = projects.find((p)=>p.id === selectedProjectId);
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: selectedProject ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: selectedProject.name
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                lineNumber: 155,
                                                                columnNumber: 27
                                                            }, this),
                                                            selectedProject.is_default && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                width: "14",
                                                                height: "14",
                                                                viewBox: "0 0 24 24",
                                                                fill: "currentColor",
                                                                className: "text-yellow-500",
                                                                "aria-hidden": "true",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                    lineNumber: 157,
                                                                    columnNumber: 31
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                lineNumber: 156,
                                                                columnNumber: 58
                                                            }, this),
                                                            selectedProject.is_shared && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                width: "14",
                                                                height: "14",
                                                                viewBox: "0 0 24 24",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                strokeWidth: "2",
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                className: "text-blue-500",
                                                                "aria-hidden": "true",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                        d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                        lineNumber: 160,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                                        cx: "9",
                                                                        cy: "7",
                                                                        r: "4"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                        lineNumber: 161,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                        d: "M23 21v-2a4 4 0 0 0-3-3.87"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                        lineNumber: 162,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                        d: "M16 3.13a4 4 0 0 1 0 7.75"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                        lineNumber: 163,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                lineNumber: 159,
                                                                columnNumber: 57
                                                            }, this)
                                                        ]
                                                    }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Geen project"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                        lineNumber: 165,
                                                        columnNumber: 31
                                                    }, this)
                                                }, void 0, false);
                                            })()
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                                            lineNumber: 149,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "p-2 -mr-2 -my-2 rounded hover:bg-gray-100 active:bg-gray-200 transition-colors touch-manipulation",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                width: "16",
                                                height: "16",
                                                viewBox: "0 0 24 24",
                                                fill: "none",
                                                stroke: "currentColor",
                                                strokeWidth: "2",
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                className: `text-gray-400 transition-transform ${openDropdowns[timerId_0] ? "rotate-180" : ""}`,
                                                "aria-hidden": "true",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                                    points: "6 9 12 15 18 9"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                    lineNumber: 171,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                lineNumber: 170,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                                            lineNumber: 169,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[user]/TimerSectionClient.js",
                                    lineNumber: 148,
                                    columnNumber: 13
                                }, this),
                                openDropdowns[timerId_0] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute top-full left-0 mt-1 bg-white rounded-lg shadow-lg border border-gray-200 z-50 min-w-[280px] max-h-60 overflow-y-auto",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>{
                                                // Dummy action - will be replaced with server call later
                                                handleProjectChange(timerId_0, null);
                                            },
                                            className: "w-full px-3 py-2 text-base text-left hover:bg-gray-100 text-gray-700 flex items-center",
                                            children: "Geen project"
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                                            lineNumber: 176,
                                            columnNumber: 17
                                        }, this),
                                        projects.map((project, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "h-px bg-gray-200"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                        lineNumber: 183,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        onClick: ()=>{
                                                            // Dummy action - will be replaced with server call later
                                                            handleProjectChange(timerId_0, project.id);
                                                        },
                                                        className: "w-full px-3 py-2 text-base text-left hover:bg-gray-100 text-gray-700 flex items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "flex-1",
                                                                children: project.name
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                lineNumber: 188,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-1.5",
                                                                children: [
                                                                    project.is_default && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        width: "14",
                                                                        height: "14",
                                                                        viewBox: "0 0 24 24",
                                                                        fill: "currentColor",
                                                                        className: "text-yellow-500",
                                                                        "aria-hidden": "true",
                                                                        title: "Standaard",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                            d: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                            lineNumber: 191,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                        lineNumber: 190,
                                                                        columnNumber: 48
                                                                    }, this),
                                                                    project.is_shared && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        width: "14",
                                                                        height: "14",
                                                                        viewBox: "0 0 24 24",
                                                                        fill: "none",
                                                                        stroke: "currentColor",
                                                                        strokeWidth: "2",
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        className: "text-blue-500",
                                                                        "aria-hidden": "true",
                                                                        title: "Gedeeld",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                                lineNumber: 194,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                                                cx: "9",
                                                                                cy: "7",
                                                                                r: "4"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                                lineNumber: 195,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                d: "M23 21v-2a4 4 0 0 0-3-3.87"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                                lineNumber: 196,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                d: "M16 3.13a4 4 0 0 1 0 7.75"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                                lineNumber: 197,
                                                                                columnNumber: 29
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                        lineNumber: 193,
                                                                        columnNumber: 47
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                                lineNumber: 189,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                        lineNumber: 184,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, project.id, true, {
                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                lineNumber: 182,
                                                columnNumber: 51
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[user]/TimerSectionClient.js",
                                    lineNumber: 175,
                                    columnNumber: 42
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                            lineNumber: 145,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-start",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-3xl font-semibold",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$RunningClockClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        startedAt: entry_1?.start_time || null,
                                        stoppedAt: stoppedAt
                                    }, void 0, false, {
                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                        lineNumber: 208,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/TimerSectionClient.js",
                                    lineNumber: 207,
                                    columnNumber: 13
                                }, this),
                                entry_1?.hourly_rate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-1 text-base font-semibold text-gray-700",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$MoneyCounterClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        startedAt: entry_1.start_time,
                                        hourlyRate: entry_1.hourly_rate,
                                        stoppedAt: stoppedAt
                                    }, void 0, false, {
                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                        lineNumber: 211,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/TimerSectionClient.js",
                                    lineNumber: 210,
                                    columnNumber: 38
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                            lineNumber: 206,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/[user]/TimerSectionClient.js",
                    lineNumber: 144,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-center shrink-0 pl-4 self-center",
                    children: isPendingTimer ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>handleStart(pending),
                        className: "w-12 h-12 rounded-full bg-green-800 hover:bg-green-600 active:bg-green-700 flex items-center justify-center transition-colors shrink-0",
                        "aria-label": "Start timer",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            "aria-hidden": "true",
                            className: "text-white",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                d: "M8 5v14l11-7-11-7z",
                                fill: "currentColor"
                            }, void 0, false, {
                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                lineNumber: 220,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                            lineNumber: 219,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                        lineNumber: 218,
                        columnNumber: 29
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>handleStop(entry_1),
                        disabled: isPending,
                        className: "w-12 h-12 rounded-full bg-orange-500 hover:bg-orange-600 active:bg-orange-700 flex items-center justify-center disabled:opacity-60 transition-colors shrink-0",
                        "aria-label": "Stop timer",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            "aria-hidden": "true",
                            className: "text-white",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                x: "7",
                                y: "7",
                                width: "10",
                                height: "10",
                                rx: "2",
                                fill: "currentColor"
                            }, void 0, false, {
                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                lineNumber: 224,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                            lineNumber: 223,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                        lineNumber: 222,
                        columnNumber: 25
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/[user]/TimerSectionClient.js",
                    lineNumber: 217,
                    columnNumber: 9
                }, this)
            ]
        }, timerId_0, true, {
            fileName: "[project]/app/[user]/TimerSectionClient.js",
            lineNumber: 142,
            columnNumber: 12
        }, this);
    };
    const renderStoppedTimer = (entry_2)=>{
        const durationMs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeEntryDurationMs"])(entry_2.start_time, entry_2.end_time, entry_2.duration_ms);
        const formattedDuration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatHM"])(durationMs);
        const [hours, minutes] = formattedDuration.split(":");
        const totalMoney = entry_2.hourly_rate && durationMs > 0 ? durationMs / (1000 * 60 * 60) * entry_2.hourly_rate : 0;
        const selectedProject_0 = projects.find((p_0)=>p_0.id === entry_2.project);
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "timer-box flex flex-col items-start mb-4 bg-white opacity-75",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between w-full",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "py-2 text-base text-gray-700 flex items-center gap-2 min-w-[200px]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "flex items-center gap-1.5 flex-1 text-left",
                            children: selectedProject_0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: selectedProject_0.name
                                    }, void 0, false, {
                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                        lineNumber: 242,
                                        columnNumber: 19
                                    }, this),
                                    selectedProject_0.is_default && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        width: "14",
                                        height: "14",
                                        viewBox: "0 0 24 24",
                                        fill: "currentColor",
                                        className: "text-yellow-500",
                                        "aria-hidden": "true",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                                            lineNumber: 244,
                                            columnNumber: 23
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                        lineNumber: 243,
                                        columnNumber: 52
                                    }, this),
                                    selectedProject_0.is_shared && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        width: "14",
                                        height: "14",
                                        viewBox: "0 0 24 24",
                                        fill: "none",
                                        stroke: "currentColor",
                                        strokeWidth: "2",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        className: "text-blue-500",
                                        "aria-hidden": "true",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"
                                            }, void 0, false, {
                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                lineNumber: 247,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                cx: "9",
                                                cy: "7",
                                                r: "4"
                                            }, void 0, false, {
                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                lineNumber: 248,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                d: "M23 21v-2a4 4 0 0 0-3-3.87"
                                            }, void 0, false, {
                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                lineNumber: 249,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                d: "M16 3.13a4 4 0 0 1 0 7.75"
                                            }, void 0, false, {
                                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                                lineNumber: 250,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                        lineNumber: 246,
                                        columnNumber: 51
                                    }, this)
                                ]
                            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Geen project"
                            }, void 0, false, {
                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                lineNumber: 252,
                                columnNumber: 23
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                            lineNumber: 240,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                        lineNumber: 239,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/[user]/TimerSectionClient.js",
                    lineNumber: 238,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-start w-full",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-3xl font-semibold",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "timer-text",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: hours
                                    }, void 0, false, {
                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                        lineNumber: 261,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "timer-colon",
                                        children: ":"
                                    }, void 0, false, {
                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                        lineNumber: 262,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: minutes
                                    }, void 0, false, {
                                        fileName: "[project]/app/[user]/TimerSectionClient.js",
                                        lineNumber: 263,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/[user]/TimerSectionClient.js",
                                lineNumber: 260,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                            lineNumber: 259,
                            columnNumber: 11
                        }, this),
                        entry_2.hourly_rate && totalMoney > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-1 text-base font-semibold text-gray-700",
                            children: [
                                "€",
                                totalMoney.toFixed(2)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[user]/TimerSectionClient.js",
                            lineNumber: 266,
                            columnNumber: 53
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/[user]/TimerSectionClient.js",
                    lineNumber: 258,
                    columnNumber: 9
                }, this)
            ]
        }, entry_2.id, true, {
            fileName: "[project]/app/[user]/TimerSectionClient.js",
            lineNumber: 236,
            columnNumber: 12
        }, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-2",
        children: allTimers.length === 0 && stoppedTimersList.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center text-gray-500 py-8",
            children: "Click the “Time toevoegen” button to create a timer"
        }, void 0, false, {
            fileName: "[project]/app/[user]/TimerSectionClient.js",
            lineNumber: 274,
            columnNumber: 67
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: allTimers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: allTimers.map((timer_2)=>renderTimer(timer_2))
            }, void 0, false)
        }, void 0, false)
    }, void 0, false, {
        fileName: "[project]/app/[user]/TimerSectionClient.js",
        lineNumber: 272,
        columnNumber: 10
    }, this);
}
_s(TimerSectionClient, "x3rXhD7tzxwreRMZYYvzGWxUtgk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"]
    ];
});
_c = TimerSectionClient;
var _c;
__turbopack_context__.k.register(_c, "TimerSectionClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[user]/TimerSectionWrapperClient.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TimerSectionWrapperClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/stores/useStore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$HeaderSectionClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/[user]/HeaderSectionClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$TimerSectionClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/[user]/TimerSectionClient.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function TimerSectionWrapperClient(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "44b0433fb8e98b436dddf2692b7eb584bbe4e78911b155d6d70db6f6589bb6be") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "44b0433fb8e98b436dddf2692b7eb584bbe4e78911b155d6d70db6f6589bb6be";
    }
    const { user, activeEntries, stoppedTimers } = t0;
    const hydrateActiveEntries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(_TimerSectionWrapperClientUseStore);
    const hydrateStoppedTimers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(_TimerSectionWrapperClientUseStore2);
    const addPendingTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(_TimerSectionWrapperClientUseStore3);
    let t1;
    let t2;
    if ($[1] !== activeEntries || $[2] !== hydrateActiveEntries || $[3] !== hydrateStoppedTimers || $[4] !== stoppedTimers) {
        t1 = ({
            "TimerSectionWrapperClient[useEffect()]": ()=>{
                hydrateActiveEntries(activeEntries);
                hydrateStoppedTimers(stoppedTimers || []);
            }
        })["TimerSectionWrapperClient[useEffect()]"];
        t2 = [
            activeEntries,
            stoppedTimers,
            hydrateActiveEntries,
            hydrateStoppedTimers
        ];
        $[1] = activeEntries;
        $[2] = hydrateActiveEntries;
        $[3] = hydrateStoppedTimers;
        $[4] = stoppedTimers;
        $[5] = t1;
        $[6] = t2;
    } else {
        t1 = $[5];
        t2 = $[6];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[7] !== addPendingTimer) {
        t3 = function handleAddTimer() {
            const newTimer = {
                id: `pending-${Date.now()}-${Math.random()}`,
                projectId: null
            };
            addPendingTimer(newTimer);
        };
        $[7] = addPendingTimer;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    const handleAddTimer = t3;
    let t4;
    if ($[9] !== handleAddTimer || $[10] !== user) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$HeaderSectionClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            user: user,
            onAddTimer: handleAddTimer
        }, void 0, false, {
            fileName: "[project]/app/[user]/TimerSectionWrapperClient.js",
            lineNumber: 62,
            columnNumber: 10
        }, this);
        $[9] = handleAddTimer;
        $[10] = user;
        $[11] = t4;
    } else {
        t4 = $[11];
    }
    let t5;
    if ($[12] !== user) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "bg-gray-100 flex-1 min-h-0 border-t border-gray-200 overflow-y-auto overscroll-contain",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pt-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$TimerSectionClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    user: user
                }, void 0, false, {
                    fileName: "[project]/app/[user]/TimerSectionWrapperClient.js",
                    lineNumber: 71,
                    columnNumber: 140
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/[user]/TimerSectionWrapperClient.js",
                lineNumber: 71,
                columnNumber: 118
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[user]/TimerSectionWrapperClient.js",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[12] = user;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    let t6;
    if ($[14] !== t4 || $[15] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t4,
                t5
            ]
        }, void 0, true);
        $[14] = t4;
        $[15] = t5;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    return t6;
}
_s(TimerSectionWrapperClient, "aIWaTU9DvhBPhwTpG65R/jNILy0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"]
    ];
});
_c = TimerSectionWrapperClient;
function _TimerSectionWrapperClientUseStore3(state_1) {
    return state_1.addPendingTimer;
}
function _TimerSectionWrapperClientUseStore2(state_0) {
    return state_0.hydrateStoppedTimers;
}
function _TimerSectionWrapperClientUseStore(state) {
    return state.hydrateActiveEntries;
}
var _c;
__turbopack_context__.k.register(_c, "TimerSectionWrapperClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[user]/DayEntriesModalClient.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DayEntriesModalClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/stores/useStore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/time.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function formatTime(isoString) {
    if (!isoString) return "";
    const date = new Date(isoString);
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    return `${hours}:${minutes}`;
}
function combineDayDateWithTime(dayDate, timeString) {
    if (!dayDate || !timeString) return null;
    const [hours, minutes] = timeString.split(":");
    // Use local date components to avoid timezone issues
    const date = new Date(dayDate);
    const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), parseInt(hours, 10) || 0, parseInt(minutes, 10) || 0, 0, 0);
    return localDate;
}
function formatHoursMinutes(ms) {
    const totalMinutes = Math.round(ms / 60000);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours}:${String(minutes).padStart(2, "0")}`;
}
function parseDuration(durationString) {
    // Parse "H:MM" or "HH:MM" format to milliseconds
    if (!durationString || durationString.trim() === "") return null;
    const parts = durationString.split(":");
    if (parts.length !== 2) return null;
    const hours = parseInt(parts[0], 10) || 0;
    const minutes = parseInt(parts[1], 10) || 0;
    return (hours * 60 + minutes) * 60 * 1000;
}
function formatDurationInput(value) {
    // Remove any non-digit characters except colon
    let cleaned = value.replace(/[^\d:]/g, "");
    // Handle different input patterns
    if (!cleaned) return "";
    // If no colon, try to intelligently format
    if (!cleaned.includes(":")) {
        // "8" -> "8:00"
        // "830" -> "8:30"
        // "1230" -> "12:30"
        if (cleaned.length <= 2) {
            return `${cleaned}:00`;
        } else if (cleaned.length === 3) {
            // "830" -> "8:30"
            return `${cleaned[0]}:${cleaned.slice(1)}`;
        } else {
            // "1230" -> "12:30"
            return `${cleaned.slice(0, -2)}:${cleaned.slice(-2)}`;
        }
    }
    // Has colon, validate and format
    const parts = cleaned.split(":");
    if (parts.length > 2) {
        // Multiple colons, keep first two parts
        return `${parts[0]}:${parts[1]}`;
    }
    const [hoursStr, minutesStr] = parts;
    const hours = parseInt(hoursStr, 10) || 0;
    let minutes = parseInt(minutesStr || "0", 10) || 0;
    // Limit minutes to 59
    if (minutes > 59) {
        minutes = 59;
    }
    // Format minutes with leading zero if needed
    const formattedMinutes = String(minutes).padStart(2, "0");
    return `${hours}:${formattedMinutes}`;
}
function DayEntriesModalClient({ isOpen, onClose, dayDate, entries, user }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const projects = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[projects]": (state)=>state.projects
    }["DayEntriesModalClient.useStore[projects]"]);
    const addEntry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[addEntry]": (state)=>state.addEntry
    }["DayEntriesModalClient.useStore[addEntry]"]);
    const updateEntry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[updateEntry]": (state)=>state.updateEntry
    }["DayEntriesModalClient.useStore[updateEntry]"]);
    const replaceTempEntry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[replaceTempEntry]": (state)=>state.replaceTempEntry
    }["DayEntriesModalClient.useStore[replaceTempEntry]"]);
    const deleteEntry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[deleteEntry]": (state)=>state.deleteEntry
    }["DayEntriesModalClient.useStore[deleteEntry]"]);
    const fetchWeekEntries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[fetchWeekEntries]": (state)=>state.fetchWeekEntries
    }["DayEntriesModalClient.useStore[fetchWeekEntries]"]);
    const expenses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[expenses]": (state)=>state.expenses
    }["DayEntriesModalClient.useStore[expenses]"]);
    const fetchDayExpenses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[fetchDayExpenses]": (state)=>state.fetchDayExpenses
    }["DayEntriesModalClient.useStore[fetchDayExpenses]"]);
    const addExpense = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[addExpense]": (state)=>state.addExpense
    }["DayEntriesModalClient.useStore[addExpense]"]);
    const updateExpense = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[updateExpense]": (state)=>state.updateExpense
    }["DayEntriesModalClient.useStore[updateExpense]"]);
    const replaceTempExpense = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[replaceTempExpense]": (state)=>state.replaceTempExpense
    }["DayEntriesModalClient.useStore[replaceTempExpense]"]);
    const deleteExpense = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[deleteExpense]": (state)=>state.deleteExpense
    }["DayEntriesModalClient.useStore[deleteExpense]"]);
    const weekOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[weekOffset]": (state)=>state.weekOffset
    }["DayEntriesModalClient.useStore[weekOffset]"]);
    const loadingExpenses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[loadingExpenses]": (state)=>state.loadingExpenses
    }["DayEntriesModalClient.useStore[loadingExpenses]"]);
    const expensesError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "DayEntriesModalClient.useStore[expensesError]": (state)=>state.expensesError
    }["DayEntriesModalClient.useStore[expensesError]"]);
    const [localEntries, setLocalEntries] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [localExpenses, setLocalExpenses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [membersCache, setMembersCache] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({}); // Cache members by projectId
    const [isSaving, setIsSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isDeleting, setIsDeleting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [successMessage, setSuccessMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("entries");
    // Extract dayDate string for dependency array
    const dayDateString = dayDate?.toISOString();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DayEntriesModalClient.useEffect": ()=>{
            if (isOpen && dayDate && !loadingExpenses && !expensesError) {
                fetchDayExpenses(user, dayDate);
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["DayEntriesModalClient.useEffect"], [
        isOpen,
        dayDateString,
        user
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DayEntriesModalClient.useEffect": ()=>{
            if (isOpen && entries && dayDate) {
                // Initialize local state with entries, sorted by created_at descending (newest first)
                const sortedEntries = [
                    ...entries
                ].sort({
                    "DayEntriesModalClient.useEffect.sortedEntries": (a, b)=>{
                        const dateA = new Date(a.created_at || a.modified_at || 0);
                        const dateB = new Date(b.created_at || b.modified_at || 0);
                        return dateB - dateA; // Descending order
                    }
                }["DayEntriesModalClient.useEffect.sortedEntries"]);
                setLocalEntries(sortedEntries.map({
                    "DayEntriesModalClient.useEffect": (entry)=>{
                        // Use duration_ms if available, otherwise calculate from start/end
                        const durationMs = entry.duration_ms ?? (entry.end_time ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeEntryDurationMs"])(entry.start_time, entry.end_time, null) : null);
                        return {
                            ...entry,
                            // Convert to editable format
                            start_time_editable: formatTime(entry.start_time),
                            end_time_editable: formatTime(entry.end_time),
                            duration_editable: durationMs ? formatHoursMinutes(durationMs) : "",
                            hourly_rate_editable: entry.hourly_rate ?? "",
                            project_editable: entry.project ?? ""
                        };
                    }
                }["DayEntriesModalClient.useEffect"]));
                setError(null);
            }
        }
    }["DayEntriesModalClient.useEffect"], [
        isOpen,
        entries,
        dayDate
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DayEntriesModalClient.useEffect": ()=>{
            if (isOpen && expenses && dayDate) {
                // Initialize local state with expenses, sorted by created_at descending (newest first)
                const sortedExpenses = [
                    ...expenses
                ].sort({
                    "DayEntriesModalClient.useEffect.sortedExpenses": (a, b)=>{
                        const dateA = new Date(a.created_at || a.modified_at || 0);
                        const dateB = new Date(b.created_at || b.modified_at || 0);
                        return dateB - dateA; // Descending order
                    }
                }["DayEntriesModalClient.useEffect.sortedExpenses"]);
                setLocalExpenses(sortedExpenses.map({
                    "DayEntriesModalClient.useEffect": (expense)=>({
                            ...expense,
                            // Convert to editable format
                            name_editable: expense.name ?? "",
                            price_editable: expense.price !== null && expense.price !== undefined ? String(expense.price) : "",
                            project_editable: expense.project ?? "",
                            includes_vat_editable: expense.includes_vat ?? false
                        })
                }["DayEntriesModalClient.useEffect"]));
            }
        }
    }["DayEntriesModalClient.useEffect"], [
        isOpen,
        expenses,
        dayDate
    ]);
    const handleEntryChange = async (index, field, value)=>{
        const updated = [
            ...localEntries
        ];
        updated[index] = {
            ...updated[index],
            [field]: value
        };
        // If project changed, check if it's a shared project and auto-populate member rate
        if (field === "project_editable" && value) {
            const selectedProject = projects.find((p)=>p.id === value);
            if (selectedProject && selectedProject.is_shared) {
                // Check cache first
                if (membersCache[value]) {
                    const members = membersCache[value];
                    const currentUserMember = members.find((m)=>m.user_name === user);
                    if (currentUserMember && currentUserMember.hourly_rate !== null && currentUserMember.hourly_rate !== undefined) {
                        updated[index].hourly_rate_editable = String(currentUserMember.hourly_rate);
                    } else if (selectedProject.hourly_rate) {
                        updated[index].hourly_rate_editable = String(selectedProject.hourly_rate);
                    }
                } else {
                    // Fetch project members to get the current user's hourly rate
                    try {
                        const res = await fetch(`/${encodeURIComponent(user)}/projecten/api?action=members&projectId=${value}`);
                        const data = await res.json();
                        const members = data.members || [];
                        // Cache the members
                        setMembersCache((prev)=>({
                                ...prev,
                                [value]: members
                            }));
                        const currentUserMember = members.find((m)=>m.user_name === user);
                        if (currentUserMember && currentUserMember.hourly_rate !== null && currentUserMember.hourly_rate !== undefined) {
                            updated[index].hourly_rate_editable = String(currentUserMember.hourly_rate);
                        } else if (selectedProject.hourly_rate) {
                            // Fall back to project rate if member rate not set
                            updated[index].hourly_rate_editable = String(selectedProject.hourly_rate);
                        }
                    } catch (error) {
                        console.error("Error fetching member rate:", error);
                        // If fetch fails, try project rate
                        if (selectedProject.hourly_rate) {
                            updated[index].hourly_rate_editable = String(selectedProject.hourly_rate);
                        }
                    }
                }
            } else if (selectedProject && selectedProject.hourly_rate) {
                // For non-shared projects, use project rate
                updated[index].hourly_rate_editable = String(selectedProject.hourly_rate);
            }
        }
        // If duration changed, just store the raw value (no formatting while typing)
        // Formatting will happen on blur
        // If start_time or end_time changed, recalculate duration (but don't overwrite duration_ms)
        if (field === "start_time_editable" || field === "end_time_editable") {
            const entry = updated[index];
            const isRunning = entry.is_running === true;
            // For running timers, calculate duration from new start_time to current time
            if (isRunning && field === "start_time_editable" && entry.start_time_editable && dayDate) {
                const newStart = combineDayDateWithTime(dayDate, entry.start_time_editable);
                if (newStart) {
                    const now = new Date();
                    const durationMs = now - newStart;
                    if (durationMs > 0) {
                        updated[index].duration_editable = formatHoursMinutes(durationMs);
                    }
                }
            } else if (entry.start_time_editable && entry.end_time_editable && dayDate && !isRunning) {
                // For non-running timers, calculate from start to end
                const start = combineDayDateWithTime(dayDate, entry.start_time_editable);
                const end = combineDayDateWithTime(dayDate, entry.end_time_editable);
                if (start && end) {
                    const durationMs = end - start;
                    if (durationMs > 0) {
                        updated[index].duration_editable = formatHoursMinutes(durationMs);
                    }
                }
            }
        }
        setLocalEntries(updated);
    };
    const handleDurationBlur = (index)=>{
        const updated = [
            ...localEntries
        ];
        const value = updated[index].duration_editable;
        if (value) {
            // Format on blur to ensure proper format
            const formatted = formatDurationInput(value);
            updated[index].duration_editable = formatted;
            setLocalEntries(updated);
        }
    };
    const handleAddEntry = ()=>{
        if (!dayDate) return;
        // Create a new entry in local state only (will be created in backend on save)
        const tempId = `temp-${Date.now()}-${Math.random()}`;
        const newEntry = {
            id: tempId,
            user_name: user,
            start_time: null,
            end_time: null,
            duration_ms: null,
            hourly_rate: null,
            project: null,
            created_at: new Date().toISOString(),
            modified_at: new Date().toISOString(),
            start_time_editable: "",
            end_time_editable: "",
            duration_editable: "",
            hourly_rate_editable: "",
            project_editable: ""
        };
        // Add new entry at the beginning (newest first)
        setLocalEntries([
            newEntry,
            ...localEntries
        ]);
    };
    const handleExpenseChange = (index, field, value)=>{
        const updated = [
            ...localExpenses
        ];
        updated[index] = {
            ...updated[index],
            [field]: value
        };
        setLocalExpenses(updated);
    };
    const handleAddExpense = ()=>{
        if (!dayDate) return;
        // Create a new expense in local state only (will be created in backend on save)
        const tempId = `temp-expense-${Date.now()}-${Math.random()}`;
        const newExpense = {
            id: tempId,
            user_name: user,
            project: null,
            name: "",
            price: null,
            includes_vat: false,
            expense_type: "materials",
            date: dayDate.toISOString(),
            created_at: new Date().toISOString(),
            modified_at: new Date().toISOString(),
            name_editable: "",
            price_editable: "",
            project_editable: "",
            includes_vat_editable: false
        };
        // Add new expense at the beginning (newest first)
        setLocalExpenses([
            newExpense,
            ...localExpenses
        ]);
    };
    const handleSave = async ()=>{
        setIsSaving(true);
        setError(null);
        setSuccessMessage(null);
        try {
            // Process each entry
            const updatePromises = localEntries.map(async (entry)=>{
                // Check if this is a new entry (has temp ID)
                const isNewEntry = entry.id && entry.id.startsWith("temp-");
                if (isNewEntry) {
                    // Create new entry in backend
                    if (!dayDate) {
                        throw new Error("Day date is required");
                    }
                    const updates = {};
                    let durationWasEdited = false;
                    // Check if start time is explicitly set by user
                    const hasStartTime = entry.start_time_editable && entry.start_time_editable.trim() !== "";
                    const hasEndTime = entry.end_time_editable && entry.end_time_editable.trim() !== "";
                    const hasBothTimes = hasStartTime && hasEndTime;
                    // Only treat duration as "edited" if user set duration but NOT start time
                    // (If start time is set, we should use it, even if duration was auto-calculated)
                    if (entry.duration_editable !== undefined && entry.duration_editable !== "" && !hasStartTime) {
                        const newDurationMs = parseDuration(entry.duration_editable);
                        if (newDurationMs !== null) {
                            updates.duration_ms = newDurationMs;
                            durationWasEdited = true;
                        }
                    }
                    // If duration was manually edited (and start time not set), calculate from day start
                    if (durationWasEdited && dayDate && updates.duration_ms) {
                        // Set start_time to start of the selected day using local date components
                        const date = new Date(dayDate);
                        const dayStart = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0);
                        // Calculate end_time from start_time + duration
                        const dayEnd = new Date(dayStart.getTime() + updates.duration_ms);
                        updates.start_time = dayStart.toISOString();
                        updates.end_time = dayEnd.toISOString();
                    } else {
                        // Use start_time and end_time if provided (prioritize these over auto-calculated duration)
                        if (entry.start_time_editable && dayDate) {
                            const newStart = combineDayDateWithTime(dayDate, entry.start_time_editable);
                            if (newStart) {
                                updates.start_time = newStart.toISOString();
                            }
                        }
                        if (entry.end_time_editable && dayDate) {
                            const newEnd = combineDayDateWithTime(dayDate, entry.end_time_editable);
                            if (newEnd) {
                                updates.end_time = newEnd.toISOString();
                            }
                        }
                        // If both start and end times are set, calculate duration from them
                        if (hasBothTimes && updates.start_time && updates.end_time) {
                            const start = new Date(updates.start_time);
                            const end = new Date(updates.end_time);
                            const durationMs = end - start;
                            if (durationMs > 0) {
                                updates.duration_ms = durationMs;
                            }
                        } else if (entry.duration_editable && entry.duration_editable !== "" && !hasStartTime) {
                            // If only duration is set (without start time), use it
                            const newDurationMs = parseDuration(entry.duration_editable);
                            if (newDurationMs !== null) {
                                updates.duration_ms = newDurationMs;
                            }
                        }
                    }
                    // Set hourly_rate if provided
                    if (entry.hourly_rate_editable !== undefined && entry.hourly_rate_editable !== "") {
                        updates.hourly_rate = parseFloat(entry.hourly_rate_editable);
                    }
                    // Set project if provided
                    if (entry.project_editable !== undefined && entry.project_editable !== "") {
                        updates.project = entry.project_editable;
                    }
                    // Create entry in backend
                    const response = await fetch(`/${encodeURIComponent(user)}/entries`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            dayDate: dayDate.toISOString(),
                            duration_ms: updates.duration_ms ?? null,
                            hourly_rate: updates.hourly_rate ?? null,
                            project: updates.project ?? null,
                            start_time: updates.start_time ?? null,
                            end_time: updates.end_time ?? null
                        })
                    });
                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error || "Failed to create entry");
                    }
                    // Parse response and replace temp entry with real entry
                    const responseData = await response.json();
                    if (responseData.entry) {
                        replaceTempEntry(entry.id, responseData.entry);
                    }
                    return {
                        success: true
                    }; // New entry created
                }
                // Existing entry - update it
                const updates = {};
                let durationWasEdited = false;
                // Check if start time is explicitly set by user
                const hasStartTime = entry.start_time_editable && entry.start_time_editable.trim() !== "";
                const hasEndTime = entry.end_time_editable && entry.end_time_editable.trim() !== "";
                const hasBothTimes = hasStartTime && hasEndTime;
                // Only treat duration as "edited" if user set duration but NOT start time
                // (If start time is set, we should use it, even if duration was auto-calculated)
                if (entry.duration_editable !== undefined && entry.duration_editable !== "" && !hasStartTime) {
                    const newDurationMs = parseDuration(entry.duration_editable);
                    const currentDurationMs = entry.duration_ms;
                    if (newDurationMs !== null && newDurationMs !== currentDurationMs) {
                        updates.duration_ms = newDurationMs;
                        durationWasEdited = true;
                    }
                }
                // If duration was manually edited (and start time not set), calculate from day start
                if (durationWasEdited && dayDate && updates.duration_ms) {
                    // Set start_time to start of the selected day using local date components
                    const date = new Date(dayDate);
                    const dayStart = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0);
                    // Calculate end_time from start_time + duration
                    const dayEnd = new Date(dayStart.getTime() + updates.duration_ms);
                    updates.start_time = dayStart.toISOString();
                    updates.end_time = dayEnd.toISOString();
                } else {
                    // Update start_time if changed (and duration wasn't manually edited)
                    if (entry.start_time_editable && !durationWasEdited && dayDate) {
                        const newStart = combineDayDateWithTime(dayDate, entry.start_time_editable);
                        if (newStart && newStart.toISOString() !== entry.start_time) {
                            updates.start_time = newStart.toISOString();
                            // For running timers, calculate duration from new start_time to current time
                            if (entry.is_running === true) {
                                const now = new Date();
                                const durationMs = now - newStart;
                                if (durationMs > 0) {
                                    updates.duration_ms = durationMs;
                                }
                            }
                        }
                    }
                    // Update end_time if changed (and duration wasn't manually edited)
                    // For running timers, don't allow end_time updates
                    if (entry.end_time_editable && !durationWasEdited && dayDate && entry.is_running !== true) {
                        const newEnd = combineDayDateWithTime(dayDate, entry.end_time_editable);
                        const currentEnd = entry.end_time ? new Date(entry.end_time).toISOString() : null;
                        if (newEnd && newEnd.toISOString() !== currentEnd) {
                            updates.end_time = newEnd.toISOString();
                        }
                    } else if (!entry.end_time_editable && entry.end_time && !durationWasEdited && entry.is_running !== true) {
                        // Handle clearing end_time (shouldn't happen for closed entries, but handle it)
                        updates.end_time = null;
                    }
                    // If both start and end times are set, calculate duration from them
                    // (Skip this for running timers as they don't have end_time)
                    if (hasBothTimes && updates.start_time && updates.end_time && entry.is_running !== true) {
                        const start = new Date(updates.start_time);
                        const end = new Date(updates.end_time);
                        const durationMs = end - start;
                        if (durationMs > 0) {
                            updates.duration_ms = durationMs;
                        }
                    } else if (entry.duration_editable && entry.duration_editable !== "" && !hasStartTime && !durationWasEdited && entry.is_running !== true) {
                        // If only duration is set (without start time), use it
                        const newDurationMs = parseDuration(entry.duration_editable);
                        if (newDurationMs !== null) {
                            const currentDurationMs = entry.duration_ms;
                            if (newDurationMs !== currentDurationMs) {
                                updates.duration_ms = newDurationMs;
                            }
                        }
                    }
                }
                // Update hourly_rate if changed
                if (entry.hourly_rate_editable !== undefined) {
                    const newRate = entry.hourly_rate_editable === "" || entry.hourly_rate_editable === null ? null : parseFloat(entry.hourly_rate_editable);
                    const currentRate = entry.hourly_rate;
                    if (newRate !== currentRate) {
                        updates.hourly_rate = newRate;
                    }
                }
                // Update project if changed
                if (entry.project_editable !== undefined) {
                    const newProject = entry.project_editable === "" || entry.project_editable === null ? null : entry.project_editable;
                    const currentProject = entry.project;
                    if (newProject !== currentProject) {
                        updates.project = newProject;
                    }
                }
                // Only make API call if there are updates
                if (Object.keys(updates).length > 0) {
                    const response = await fetch(`/${encodeURIComponent(user)}/entries/${entry.id}`, {
                        method: "PATCH",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(updates)
                    });
                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error || "Failed to update entry");
                    }
                    // Parse response and update store with full entry object
                    const responseData = await response.json();
                    if (responseData.entry) {
                        updateEntry(entry.id, responseData.entry);
                    }
                    return {
                        success: true
                    };
                }
                return {
                    success: true
                }; // No updates needed
            });
            await Promise.all(updatePromises);
            // Process each expense
            const expensePromises = localExpenses.map(async (expense)=>{
                // Check if this is a new expense (has temp ID)
                const isNewExpense = expense.id && expense.id.startsWith("temp-expense-");
                if (isNewExpense) {
                    // Create new expense in backend
                    if (!dayDate) {
                        throw new Error("Day date is required");
                    }
                    if (!expense.project_editable || expense.project_editable === "") {
                        throw new Error("Project is required for expense");
                    }
                    if (!expense.name_editable || expense.name_editable.trim() === "") {
                        throw new Error("Name is required for expense");
                    }
                    if (!expense.price_editable || expense.price_editable === "") {
                        throw new Error("Price is required for expense");
                    }
                    const response = await fetch(`/${encodeURIComponent(user)}/expenses`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            dayDate: dayDate.toISOString(),
                            project: expense.project_editable,
                            name: expense.name_editable.trim(),
                            price: parseFloat(expense.price_editable),
                            includes_vat: expense.includes_vat_editable ?? false,
                            expense_type: "materials"
                        })
                    });
                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error || "Failed to create expense");
                    }
                    // Parse response and replace temp expense with real expense
                    const responseData = await response.json();
                    if (responseData.expense) {
                        replaceTempExpense(expense.id, responseData.expense);
                    }
                    return {
                        success: true
                    };
                }
                // Existing expense - update it
                const updates = {};
                // Update name if changed
                if (expense.name_editable !== undefined) {
                    const newName = expense.name_editable.trim();
                    if (newName !== expense.name) {
                        updates.name = newName;
                    }
                }
                // Update price if changed
                if (expense.price_editable !== undefined) {
                    const newPrice = expense.price_editable === "" || expense.price_editable === null ? null : parseFloat(expense.price_editable);
                    const currentPrice = expense.price;
                    if (newPrice !== currentPrice) {
                        updates.price = newPrice;
                    }
                }
                // Update includes_vat if changed
                if (expense.includes_vat_editable !== undefined) {
                    const newIncludesVat = Boolean(expense.includes_vat_editable);
                    const currentIncludesVat = expense.includes_vat ?? false;
                    if (newIncludesVat !== currentIncludesVat) {
                        updates.includes_vat = newIncludesVat;
                    }
                }
                // Update project if changed
                if (expense.project_editable !== undefined) {
                    const newProject = expense.project_editable === "" || expense.project_editable === null ? null : expense.project_editable;
                    const currentProject = expense.project;
                    if (newProject !== currentProject) {
                        updates.project = newProject;
                    }
                }
                // Only make API call if there are updates
                if (Object.keys(updates).length > 0) {
                    const response = await fetch(`/${encodeURIComponent(user)}/expenses/${expense.id}`, {
                        method: "PATCH",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(updates)
                    });
                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error || "Failed to update expense");
                    }
                    // Parse response and update store with full expense object
                    const responseData = await response.json();
                    if (responseData.expense) {
                        updateExpense(expense.id, responseData.expense);
                    }
                    return {
                        success: true
                    };
                }
                return {
                    success: true
                }; // No updates needed
            });
            await Promise.all(expensePromises);
            // Show success message
            setSuccessMessage("Wijzigingen opgeslagen");
            setIsSaving(false);
            // Wait briefly to show success message, then close modal
            setTimeout(()=>{
                handleCancel();
            }, 1500);
        } catch (err) {
            setError(err.message || "Failed to save changes");
            setIsSaving(false);
        // Keep modal open on error so user can retry
        }
    };
    const handleDeleteEntry = async (entryId, index)=>{
        if (!confirm("Weet je zeker dat je deze entry wilt verwijderen?")) {
            return;
        }
        setIsDeleting(true);
        setError(null);
        try {
            const response = await fetch(`/${encodeURIComponent(user)}/entries/${entryId}`, {
                method: "DELETE"
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to delete entry");
            }
            // Optimistically delete from store
            deleteEntry(entryId);
            // Remove from local state immediately
            const updated = localEntries.filter((_, i)=>i !== index);
            setLocalEntries(updated);
            setIsDeleting(false);
            // Refetch week entries to get updated data
            const referenceDate = new Date(new Date().getTime() + weekOffset * 7 * 24 * 60 * 60 * 1000);
            const { start: weekStart, end: weekEnd } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWeekBounds"])(referenceDate);
            await fetchWeekEntries(user, (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toIso"])(weekStart), (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toIso"])(weekEnd));
            // Refresh router for active timers
            router.refresh();
            // If no entries left, close drawer
            if (updated.length === 0) {
                handleCancel();
            }
        } catch (err) {
            setError(err.message || "Failed to delete entry");
            setIsDeleting(false);
        }
    };
    const handleDeleteExpense = async (expenseId, index)=>{
        if (!confirm("Weet je zeker dat je deze uitgave wilt verwijderen?")) {
            return;
        }
        setIsDeleting(true);
        setError(null);
        try {
            const response = await fetch(`/${encodeURIComponent(user)}/expenses/${expenseId}`, {
                method: "DELETE"
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to delete expense");
            }
            // Optimistically delete from store
            deleteExpense(expenseId);
            // Remove from local state immediately
            const updated = localExpenses.filter((_, i)=>i !== index);
            setLocalExpenses(updated);
            setIsDeleting(false);
            // Refetch day expenses
            await fetchDayExpenses(user, dayDate);
        } catch (err) {
            setError(err.message || "Failed to delete expense");
            setIsDeleting(false);
        }
    };
    const handleCancel = ()=>{
        setLocalEntries([]);
        setLocalExpenses([]);
        setError(null);
        setSuccessMessage(null);
        setIsSaving(false);
        setIsDeleting(false);
        setActiveTab("entries");
        onClose();
    };
    const handleTabChange = (tab)=>{
        setActiveTab(tab);
    };
    // Calculate summary totals for entries
    const calculateEntrySummary = ()=>{
        const entryCount = localEntries.length;
        let totalHoursMs = 0;
        let totalPrice = 0;
        localEntries.forEach((entry)=>{
            const durationMs = entry.duration_ms ?? (entry.end_time ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeEntryDurationMs"])(entry.start_time, entry.end_time, null) : 0);
            totalHoursMs += durationMs || 0;
            if (durationMs) {
                const hourlyRate = entry.hourly_rate_editable !== undefined && entry.hourly_rate_editable !== "" ? parseFloat(entry.hourly_rate_editable) : entry.hourly_rate;
                if (hourlyRate) {
                    const hours = durationMs / (1000 * 60 * 60);
                    totalPrice += hours * hourlyRate;
                }
            }
        });
        return {
            count: entryCount,
            totalHours: formatHoursMinutes(totalHoursMs),
            totalPrice: totalPrice.toFixed(2)
        };
    };
    // Calculate summary totals for expenses
    const calculateExpenseSummary = ()=>{
        const expenseCount = localExpenses.length;
        let totalPrice = 0;
        localExpenses.forEach((expense)=>{
            const price = parseFloat(expense.price_editable || expense.price || 0);
            totalPrice += price || 0;
        });
        return {
            count: expenseCount,
            totalPrice: totalPrice.toFixed(2)
        };
    };
    const entrySummary = calculateEntrySummary();
    const expenseSummary = calculateExpenseSummary();
    const dayDateFormatted = dayDate ? dayDate.toLocaleDateString("nl-NL", {
        weekday: "short",
        year: "2-digit",
        month: "short",
        day: "numeric"
    }) : "";
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 bg-black/50 z-50 transition-opacity duration-300",
        onClick: handleCancel,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-x-0 bottom-0 bg-white rounded-t-xl shadow-2xl h-full flex flex-col transition-transform duration-300 ease-out translate-y-0 pb-[env(safe-area-inset-bottom)]",
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white z-10 border-b border-gray-200 shrink-0",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-4 sm:px-6 py-4 flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg sm:text-base font-semibold text-gray-900",
                                    children: [
                                        "Bewerk entries - ",
                                        dayDateFormatted
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 822,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleCancel,
                                    className: "text-gray-400 hover:text-gray-600 text-2xl leading-none",
                                    "aria-label": "Sluiten",
                                    children: "×"
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 825,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                            lineNumber: 821,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex border-b border-gray-200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>handleTabChange("entries"),
                                    className: `flex-1 px-4 py-3 text-sm font-medium transition-colors ${activeTab === "entries" ? "text-[#008eff] border-b-2 border-[#008eff]" : "text-gray-500 hover:text-gray-700"}`,
                                    children: "Tijdregistraties"
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 831,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>handleTabChange("expenses"),
                                    className: `flex-1 px-4 py-3 text-sm font-medium transition-colors ${activeTab === "expenses" ? "text-[#008eff] border-b-2 border-[#008eff]" : "text-gray-500 hover:text-gray-700"}`,
                                    children: "Uitgaven"
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 834,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                            lineNumber: 830,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                    lineNumber: 820,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 overflow-y-auto p-4 sm:p-6 bg-[#f2f2f2]",
                    children: [
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4",
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                            lineNumber: 841,
                            columnNumber: 21
                        }, this),
                        successMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded mb-4",
                            children: successMessage
                        }, void 0, false, {
                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                            lineNumber: 844,
                            columnNumber: 30
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: activeTab === "entries" ? "" : "hidden",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-white rounded-lg p-4 mb-4 shadow-sm",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between flex-wrap gap-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-gray-500 uppercase tracking-wide",
                                                            children: "Aantal entries"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 855,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-lg font-semibold text-gray-900",
                                                            children: entrySummary.count
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 858,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                    lineNumber: 854,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-gray-500 uppercase tracking-wide",
                                                            children: "Totaal uren"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 863,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-lg font-semibold text-gray-900",
                                                            children: entrySummary.totalHours
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 866,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                    lineNumber: 862,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-gray-500 uppercase tracking-wide",
                                                            children: "Totaal prijs"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 871,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-lg font-semibold text-gray-900",
                                                            children: [
                                                                "€",
                                                                entrySummary.totalPrice
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 874,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                    lineNumber: 870,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                            lineNumber: 853,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                        lineNumber: 852,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 851,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleAddEntry,
                                        disabled: isSaving || isDeleting,
                                        className: "w-full sm:w-auto px-4 py-2 bg-[#008eff] text-white rounded-md hover:bg-[#0066b3] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm font-medium",
                                        "aria-label": "Entry toevoegen",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xl",
                                                children: "+"
                                            }, void 0, false, {
                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                lineNumber: 885,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Entry toevoegen"
                                            }, void 0, false, {
                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                lineNumber: 886,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                        lineNumber: 884,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 883,
                                    columnNumber: 13
                                }, this),
                                localEntries.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-gray-500 text-center py-8 bg-white rounded-lg",
                                    children: "Geen entries gevonden voor deze dag"
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 891,
                                    columnNumber: 42
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: localEntries.map((entry, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "rounded-lg p-4 space-y-4 bg-white",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-sm font-medium text-gray-700",
                                                            children: [
                                                                "Entry ",
                                                                index + 1
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 896,
                                                            columnNumber: 23
                                                        }, this),
                                                        entry.id && !entry.id.startsWith("temp-") && entry.is_running !== true && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleDeleteEntry(entry.id, index),
                                                            disabled: isSaving || isDeleting,
                                                            className: "text-red-500 hover:text-red-700 disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium",
                                                            "aria-label": "Entry verwijderen",
                                                            children: "Verwijderen"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 899,
                                                            columnNumber: 98
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                    lineNumber: 895,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-4",
                                                    children: [
                                                        entry.is_running === true && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mb-2 px-3 py-2 bg-[#008eff]/10 border border-[#008eff]/20 rounded-md",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-sm font-medium text-[#008eff]",
                                                                children: "⏱️ Timer actief"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                lineNumber: 906,
                                                                columnNumber: 27
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 905,
                                                            columnNumber: 53
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-gray-700 mb-1",
                                                                    children: "Projectnaam *"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                    lineNumber: 911,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                    value: entry.project_editable !== undefined ? entry.project_editable || "" : entry.project || "",
                                                                    onChange: (e)=>handleEntryChange(index, "project_editable", e.target.value || null),
                                                                    disabled: isSaving || isDeleting,
                                                                    className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#008eff] text-base disabled:opacity-50 disabled:cursor-not-allowed",
                                                                    required: true,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "",
                                                                            children: "Selecteer een project"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                            lineNumber: 915,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        projects.map((project)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                value: project.id,
                                                                                children: [
                                                                                    project.name,
                                                                                    project.is_default && " (Standaard)",
                                                                                    project.is_shared && " (Gedeeld)"
                                                                                ]
                                                                            }, project.id, true, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 916,
                                                                                columnNumber: 52
                                                                            }, this))
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                    lineNumber: 914,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 910,
                                                            columnNumber: 23
                                                        }, this),
                                                        (entry.project_editable || entry.project) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: entry.is_running === true ? // For running timers: only show start time and hourly rate
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                                                children: [
                                                                                    "Starttijd",
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        className: "ml-2 text-xs text-[#008eff] font-normal",
                                                                                        children: "(bewerkbaar)"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 932,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 930,
                                                                                columnNumber: 33
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                type: "time",
                                                                                value: entry.start_time_editable || "",
                                                                                onChange: (e)=>handleEntryChange(index, "start_time_editable", e.target.value),
                                                                                disabled: isSaving || isDeleting,
                                                                                className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#008eff] text-base disabled:opacity-50 disabled:cursor-not-allowed"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 936,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                        lineNumber: 929,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                                                children: "Uurtarief (€)"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 940,
                                                                                columnNumber: 33
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                type: "number",
                                                                                step: "0.01",
                                                                                min: "0",
                                                                                placeholder: "0.00",
                                                                                value: entry.hourly_rate_editable !== undefined ? entry.hourly_rate_editable : entry.hourly_rate || "",
                                                                                onChange: (e)=>handleEntryChange(index, "hourly_rate_editable", e.target.value === "" ? "" : e.target.value),
                                                                                disabled: isSaving || isDeleting,
                                                                                className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#008eff] text-base disabled:opacity-50 disabled:cursor-not-allowed"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 943,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                        lineNumber: 939,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                ]
                                                            }, void 0, true) : // For non-running timers: show all fields
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "grid grid-cols-2 gap-4",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                                                                        children: "Starttijd"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 950,
                                                                                        columnNumber: 35
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                        type: "time",
                                                                                        value: entry.start_time_editable || "",
                                                                                        onChange: (e)=>handleEntryChange(index, "start_time_editable", e.target.value),
                                                                                        disabled: isSaving || isDeleting,
                                                                                        className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#008eff] text-base disabled:opacity-50 disabled:cursor-not-allowed"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 953,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 949,
                                                                                columnNumber: 33
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                                                                        children: "Eindtijd"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 957,
                                                                                        columnNumber: 35
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                        type: "time",
                                                                                        value: entry.end_time_editable || "",
                                                                                        onChange: (e)=>handleEntryChange(index, "end_time_editable", e.target.value),
                                                                                        disabled: isSaving || isDeleting,
                                                                                        className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#008eff] text-base disabled:opacity-50 disabled:cursor-not-allowed"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 960,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 956,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                        lineNumber: 948,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "grid grid-cols-2 gap-4",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                                                                        children: "Duur (U:MM)"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 966,
                                                                                        columnNumber: 35
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                        type: "text",
                                                                                        placeholder: "0:00",
                                                                                        value: entry.duration_editable || "",
                                                                                        onChange: (e)=>handleEntryChange(index, "duration_editable", e.target.value),
                                                                                        onBlur: ()=>handleDurationBlur(index),
                                                                                        pattern: "[0-9]+:[0-5][0-9]",
                                                                                        disabled: isSaving || isDeleting,
                                                                                        className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#008eff] text-base disabled:opacity-50 disabled:cursor-not-allowed"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 969,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 965,
                                                                                columnNumber: 33
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                                                                        children: "Uurtarief (€)"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 973,
                                                                                        columnNumber: 35
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                        type: "number",
                                                                                        step: "0.01",
                                                                                        min: "0",
                                                                                        placeholder: "0.00",
                                                                                        value: entry.hourly_rate_editable !== undefined ? entry.hourly_rate_editable : entry.hourly_rate || "",
                                                                                        onChange: (e)=>handleEntryChange(index, "hourly_rate_editable", e.target.value === "" ? "" : e.target.value),
                                                                                        disabled: isSaving || isDeleting,
                                                                                        className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#008eff] text-base disabled:opacity-50 disabled:cursor-not-allowed"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 976,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 972,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                        lineNumber: 964,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                ]
                                                            }, void 0, true)
                                                        }, void 0, false)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                    lineNumber: 904,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, entry.id, true, {
                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                            lineNumber: 894,
                                            columnNumber: 53
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 893,
                                    columnNumber: 22
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                            lineNumber: 849,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: activeTab === "expenses" ? "" : "hidden",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-white rounded-lg p-4 mb-4 shadow-sm",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between flex-wrap gap-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-gray-500 uppercase tracking-wide",
                                                            children: "Aantal uitgaven"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 993,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-lg font-semibold text-gray-900",
                                                            children: expenseSummary.count
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 996,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                    lineNumber: 992,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-gray-500 uppercase tracking-wide",
                                                            children: "Totaal prijs"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 1001,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-lg font-semibold text-gray-900",
                                                            children: [
                                                                "€",
                                                                expenseSummary.totalPrice
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 1004,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                    lineNumber: 1000,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                            lineNumber: 991,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                        lineNumber: 990,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 989,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleAddExpense,
                                        disabled: isSaving || isDeleting,
                                        className: "w-full sm:w-auto px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm font-medium",
                                        "aria-label": "Uitgave toevoegen",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xl",
                                                children: "+"
                                            }, void 0, false, {
                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                lineNumber: 1015,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Uitgave toevoegen"
                                            }, void 0, false, {
                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                lineNumber: 1016,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                        lineNumber: 1014,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 1013,
                                    columnNumber: 13
                                }, this),
                                localExpenses.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-gray-500 text-center py-8 bg-white rounded-lg",
                                    children: "Geen uitgaven gevonden voor deze dag"
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 1021,
                                    columnNumber: 43
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: localExpenses.map((expense, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "rounded-lg p-4 space-y-4 bg-white",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-sm font-medium text-gray-700",
                                                            children: [
                                                                "Uitgave ",
                                                                index + 1
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 1026,
                                                            columnNumber: 23
                                                        }, this),
                                                        expense.id && !expense.id.startsWith("temp-expense-") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleDeleteExpense(expense.id, index),
                                                            disabled: isSaving || isDeleting,
                                                            className: "text-red-500 hover:text-red-700 disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium",
                                                            "aria-label": "Uitgave verwijderen",
                                                            children: "Verwijderen"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 1029,
                                                            columnNumber: 81
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                    lineNumber: 1025,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-gray-700 mb-1",
                                                                    children: "Projectnaam *"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                    lineNumber: 1036,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                    value: expense.project_editable !== undefined ? expense.project_editable || "" : expense.project || "",
                                                                    onChange: (e)=>handleExpenseChange(index, "project_editable", e.target.value || null),
                                                                    disabled: isSaving || isDeleting,
                                                                    className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#008eff] text-base disabled:opacity-50 disabled:cursor-not-allowed",
                                                                    required: true,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "",
                                                                            children: "Selecteer een project"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                            lineNumber: 1040,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        projects.map((project)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                value: project.id,
                                                                                children: [
                                                                                    project.name,
                                                                                    project.is_default && " (Standaard)",
                                                                                    project.is_shared && " (Gedeeld)"
                                                                                ]
                                                                            }, project.id, true, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 1041,
                                                                                columnNumber: 52
                                                                            }, this))
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                    lineNumber: 1039,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                            lineNumber: 1035,
                                                            columnNumber: 23
                                                        }, this),
                                                        (expense.project_editable || expense.project) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "block text-sm font-medium text-gray-700 mb-1",
                                                                            children: "Naam *"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                            lineNumber: 1052,
                                                                            columnNumber: 29
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            type: "text",
                                                                            value: expense.name_editable || "",
                                                                            onChange: (e)=>handleExpenseChange(index, "name_editable", e.target.value),
                                                                            disabled: isSaving || isDeleting,
                                                                            className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#008eff] text-base disabled:opacity-50 disabled:cursor-not-allowed",
                                                                            placeholder: "Bijv. Materialen, Lunch, etc.",
                                                                            required: true
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                            lineNumber: 1055,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                    lineNumber: 1051,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "grid grid-cols-2 gap-4",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                    className: "block text-sm font-medium text-gray-700 mb-1",
                                                                                    children: "Prijs (€) *"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                    lineNumber: 1060,
                                                                                    columnNumber: 31
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                    type: "number",
                                                                                    step: "0.01",
                                                                                    min: "0",
                                                                                    placeholder: "0.00",
                                                                                    value: expense.price_editable || "",
                                                                                    onChange: (e)=>handleExpenseChange(index, "price_editable", e.target.value === "" ? "" : e.target.value),
                                                                                    disabled: isSaving || isDeleting,
                                                                                    className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#008eff] text-base disabled:opacity-50 disabled:cursor-not-allowed",
                                                                                    required: true
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                    lineNumber: 1063,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                            lineNumber: 1059,
                                                                            columnNumber: 29
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-end",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                className: "flex items-center space-x-2 cursor-pointer",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                        type: "checkbox",
                                                                                        checked: expense.includes_vat_editable || false,
                                                                                        onChange: (e)=>handleExpenseChange(index, "includes_vat_editable", e.target.checked),
                                                                                        disabled: isSaving || isDeleting,
                                                                                        className: "w-4 h-4 text-[#008eff] border-gray-300 rounded focus:ring-[#008eff] disabled:opacity-50 disabled:cursor-not-allowed"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 1068,
                                                                                        columnNumber: 33
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        className: "text-sm font-medium text-gray-700",
                                                                                        children: "Inclusief BTW"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                        lineNumber: 1069,
                                                                                        columnNumber: 33
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                                lineNumber: 1067,
                                                                                columnNumber: 31
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                            lineNumber: 1066,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                                    lineNumber: 1058,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                                    lineNumber: 1034,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, expense.id, true, {
                                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                            lineNumber: 1024,
                                            columnNumber: 56
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                                    lineNumber: 1023,
                                    columnNumber: 22
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                            lineNumber: 987,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                    lineNumber: 840,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white z-10 border-t border-gray-200 px-4 sm:px-6 py-4 flex justify-end gap-3 shrink-0",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleCancel,
                            disabled: isSaving || isDeleting,
                            className: "px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 disabled:opacity-50",
                            children: "Annuleren"
                        }, void 0, false, {
                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                            lineNumber: 1083,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleSave,
                            disabled: isSaving || isDeleting || localEntries.length === 0 && localExpenses.length === 0,
                            className: "px-4 py-2 bg-[#008eff] text-white rounded-md hover:bg-[#0066b3] disabled:opacity-50 disabled:cursor-not-allowed",
                            children: isSaving ? "Opslaan..." : "Wijzigingen opslaan"
                        }, void 0, false, {
                            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                            lineNumber: 1086,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/[user]/DayEntriesModalClient.js",
                    lineNumber: 1082,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/[user]/DayEntriesModalClient.js",
            lineNumber: 819,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/[user]/DayEntriesModalClient.js",
        lineNumber: 818,
        columnNumber: 10
    }, this);
}
_s(DayEntriesModalClient, "ruzP8mXAEZWGaK4MSqS13Sr8p44=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"]
    ];
});
_c = DayEntriesModalClient;
var _c;
__turbopack_context__.k.register(_c, "DayEntriesModalClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[user]/DayClickableClient.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DayClickableClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/stores/useStore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$DayEntriesModalClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/[user]/DayEntriesModalClient.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function isSameDay(date1, date2) {
    if (!date1 || !date2) return false;
    return date1.getFullYear() === date2.getFullYear() && date1.getMonth() === date2.getMonth() && date1.getDate() === date2.getDate();
}
function filterEntriesForDay(entries, dayDate) {
    if (!entries || !dayDate) return [];
    const dayStart = new Date(dayDate);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayDate);
    dayEnd.setHours(23, 59, 59, 999);
    return entries.filter((entry)=>{
        // For entries with duration_ms, check if start_time matches the day
        // (start_time should be set to the start of the day when duration_ms is used)
        if (entry.duration_ms !== null && entry.duration_ms !== undefined && entry.start_time) {
            const entryStart = new Date(entry.start_time);
            if (isSameDay(entryStart, dayDate)) {
                return true;
            }
        }
        // For time-based entries, check if entry starts on this day or overlaps
        const entryStart = new Date(entry.start_time);
        // Entry is on this day if it starts on this day
        if (isSameDay(entryStart, dayDate)) {
            return true;
        }
        // Also include entries that span multiple days if they overlap with this day
        const entryEnd = entry.end_time ? new Date(entry.end_time) : new Date();
        if (entryStart <= dayEnd && entryEnd >= dayStart) {
            return true;
        }
        return false;
    });
}
function DayClickableClient(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "a0692525af6c92ecedb2bffd8a68b08542c71e1443c46dd54c8a725bc7eeaaaf") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a0692525af6c92ecedb2bffd8a68b08542c71e1443c46dd54c8a725bc7eeaaaf";
    }
    const { dayDate, dayLabel, user, children } = t0;
    const [isModalOpen, setIsModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const entries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(_DayClickableClientUseStore);
    const activeEntries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(_DayClickableClientUseStore2);
    let t1;
    if ($[1] !== activeEntries || $[2] !== dayDate || $[3] !== entries) {
        const allEntries = [
            ...entries
        ];
        activeEntries.forEach({
            "DayClickableClient[activeEntries.forEach()]": (activeEntry)=>{
                if (!allEntries.find({
                    "DayClickableClient[activeEntries.forEach() > allEntries.find()]": (e)=>e.id === activeEntry.id
                }["DayClickableClient[activeEntries.forEach() > allEntries.find()]"])) {
                    allEntries.push(activeEntry);
                }
            }
        }["DayClickableClient[activeEntries.forEach()]"]);
        t1 = filterEntriesForDay(allEntries, dayDate);
        $[1] = activeEntries;
        $[2] = dayDate;
        $[3] = entries;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    const dayEntries = t1;
    let t2;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "DayClickableClient[handleDayClick]": ()=>{
                setIsModalOpen(true);
            }
        })["DayClickableClient[handleDayClick]"];
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    const handleDayClick = t2;
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "DayClickableClient[<div>.onKeyDown]": (e_0)=>{
                if (e_0.key === "Enter" || e_0.key === " ") {
                    e_0.preventDefault();
                    handleDayClick();
                }
            }
        })["DayClickableClient[<div>.onKeyDown]"];
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const t4 = `Edit entries for ${dayLabel}`;
    let t5;
    if ($[7] !== children || $[8] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "day flex flex-col items-center w-full cursor-pointer hover:bg-gray-50 rounded-lg p-1 transition-colors",
            onClick: handleDayClick,
            role: "button",
            tabIndex: 0,
            onKeyDown: t3,
            "aria-label": t4,
            children: children
        }, void 0, false, {
            fileName: "[project]/app/[user]/DayClickableClient.js",
            lineNumber: 110,
            columnNumber: 10
        }, this);
        $[7] = children;
        $[8] = t4;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "DayClickableClient[<DayEntriesModalClient>.onClose]": ()=>setIsModalOpen(false)
        })["DayClickableClient[<DayEntriesModalClient>.onClose]"];
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    let t7;
    if ($[11] !== dayDate || $[12] !== dayEntries || $[13] !== isModalOpen || $[14] !== user) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$DayEntriesModalClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            isOpen: isModalOpen,
            onClose: t6,
            dayDate: dayDate,
            entries: dayEntries,
            user: user
        }, void 0, false, {
            fileName: "[project]/app/[user]/DayClickableClient.js",
            lineNumber: 128,
            columnNumber: 10
        }, this);
        $[11] = dayDate;
        $[12] = dayEntries;
        $[13] = isModalOpen;
        $[14] = user;
        $[15] = t7;
    } else {
        t7 = $[15];
    }
    let t8;
    if ($[16] !== t5 || $[17] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t5,
                t7
            ]
        }, void 0, true);
        $[16] = t5;
        $[17] = t7;
        $[18] = t8;
    } else {
        t8 = $[18];
    }
    return t8;
}
_s(DayClickableClient, "JCJNfcgDrXK/P/LMLMQdrmjYsWA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"]
    ];
});
_c = DayClickableClient;
function _DayClickableClientUseStore2(state_0) {
    return state_0.activeEntries;
}
function _DayClickableClientUseStore(state) {
    return state.entries;
}
var _c;
__turbopack_context__.k.register(_c, "DayClickableClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[user]/WeekEntriesClient.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WeekEntriesClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/stores/useStore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/time.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$DayClickableClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/[user]/DayClickableClient.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function formatHoursHMM(ms) {
    const totalMinutes = Math.round(ms / 60000);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours}:${String(minutes).padStart(2, "0")}`;
}
function formatMoney(amount) {
    return new Intl.NumberFormat("nl-NL", {
        style: "currency",
        currency: "EUR",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}
function WeekEntriesClient({ user, weekOffset }) {
    _s();
    const entries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "WeekEntriesClient.useStore[entries]": (state)=>state.entries
    }["WeekEntriesClient.useStore[entries]"]);
    const loadingEntries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "WeekEntriesClient.useStore[loadingEntries]": (state)=>state.loadingEntries
    }["WeekEntriesClient.useStore[loadingEntries]"]);
    const fetchWeekEntries = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "WeekEntriesClient.useStore[fetchWeekEntries]": (state)=>state.fetchWeekEntries
    }["WeekEntriesClient.useStore[fetchWeekEntries]"]);
    const weekExpenses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "WeekEntriesClient.useStore[weekExpenses]": (state)=>state.weekExpenses
    }["WeekEntriesClient.useStore[weekExpenses]"]);
    const fetchWeekExpenses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "WeekEntriesClient.useStore[fetchWeekExpenses]": (state)=>state.fetchWeekExpenses
    }["WeekEntriesClient.useStore[fetchWeekExpenses]"]);
    const storeWeekOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "WeekEntriesClient.useStore[storeWeekOffset]": (state)=>state.weekOffset
    }["WeekEntriesClient.useStore[storeWeekOffset]"]);
    const setWeekOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "WeekEntriesClient.useStore[setWeekOffset]": (state)=>state.setWeekOffset
    }["WeekEntriesClient.useStore[setWeekOffset]"]);
    const projects = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])({
        "WeekEntriesClient.useStore[projects]": (state)=>state.projects
    }["WeekEntriesClient.useStore[projects]"]);
    // Sync weekOffset with store
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WeekEntriesClient.useEffect": ()=>{
            if (storeWeekOffset !== weekOffset) {
                setWeekOffset(weekOffset);
            }
        }
    }["WeekEntriesClient.useEffect"], [
        weekOffset,
        storeWeekOffset,
        setWeekOffset
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WeekEntriesClient.useEffect": ()=>{
            // Calculate week bounds ONCE
            const referenceDate = new Date(new Date().getTime() + weekOffset * 7 * 24 * 60 * 60 * 1000);
            const { start: weekStart, end: weekEnd } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWeekBounds"])(referenceDate);
            const weekStartIso = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toIso"])(weekStart);
            const weekEndIso = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toIso"])(weekEnd);
            // Fetch both entries and expenses together
            fetchWeekEntries(user, weekStartIso, weekEndIso);
            fetchWeekExpenses(user, weekStartIso, weekEndIso);
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["WeekEntriesClient.useEffect"], [
        user,
        weekOffset
    ]);
    // Calculate week bounds for rendering
    const referenceDate = new Date(new Date().getTime() + weekOffset * 7 * 24 * 60 * 60 * 1000);
    const { start: weekStart, end: weekEnd } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWeekBounds"])(referenceDate);
    // Calculate perDay, perDayMoney, and perDayExpenses
    const perDay = Array(7).fill(0);
    const perDayMoney = Array(7).fill(0);
    const perDayExpenses = Array(7).fill(0);
    for (const e of entries){
        // Calculate duration clipped to week bounds (duration_ms takes precedence)
        const duration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeEntryDurationMsClipped"])(e.start_time, e.end_time, weekStart, weekEnd, e.duration_ms ?? null);
        // Only process entries that have duration within the week
        if (duration === 0) continue;
        // Determine which day to assign this entry to
        let dayIndex = -1;
        // If entry has duration_ms, use start_time to determine the day
        // (start_time should be set to the start of the day when duration_ms is set)
        if (e.duration_ms !== null && e.duration_ms !== undefined && e.start_time) {
            const entryStart = new Date(e.start_time);
            const dow = entryStart.getDay();
            dayIndex = (dow + 6) % 7; // Monday=0
        } else {
            // For time-based entries, use the start time to determine the day
            const entryStart = new Date(e.start_time);
            // Use the clipped start time if entry starts before the week
            const clippedStart = entryStart > weekStart ? entryStart : weekStart;
            const dow = clippedStart.getDay();
            dayIndex = (dow + 6) % 7; // Monday=0
        }
        if (dayIndex >= 0 && dayIndex < 7) {
            perDay[dayIndex] += duration;
            // Calculate money for this entry
            if (e.hourly_rate) {
                const hours = duration / (1000 * 60 * 60);
                const money = hours * e.hourly_rate;
                perDayMoney[dayIndex] += money;
            }
        }
    }
    // Calculate per-day expenses
    for (const expense of weekExpenses){
        if (expense.date) {
            const expenseDate = new Date(expense.date);
            const dow = expenseDate.getDay();
            const dayIndex = (dow + 6) % 7; // Monday=0
            if (dayIndex >= 0 && dayIndex < 7) {
                const price = expense.price || 0;
                perDayExpenses[dayIndex] += price;
            }
        }
    }
    const maxMs = Math.max(1, ...perDay);
    const weekTotalTime = perDay.reduce((sum, val)=>sum + val, 0);
    const weekTotalMoney = perDayMoney.reduce((sum, val)=>sum + val, 0);
    const weekTotalExpenses = perDayExpenses.reduce((sum, val)=>sum + val, 0);
    // Show spinner while loading
    if (loadingEntries) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "w-full mt-auto pb-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center py-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "animate-spin rounded-full h-8 w-8 border-b-2 border-[#008eff]"
                    }, void 0, false, {
                        fileName: "[project]/app/[user]/WeekEntriesClient.js",
                        lineNumber: 126,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ml-3 text-gray-600",
                        children: "Laden..."
                    }, void 0, false, {
                        fileName: "[project]/app/[user]/WeekEntriesClient.js",
                        lineNumber: 127,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/[user]/WeekEntriesClient.js",
                lineNumber: 125,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/[user]/WeekEntriesClient.js",
            lineNumber: 124,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "w-full mt-auto pb-4 border-t border-gray-200",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: `/${encodeURIComponent(user)}?w=${weekOffset - 1}`,
                        className: " rounded-full text-gray-600 hover:bg-gray-100 text-5xl sm:text-4xl min-w-[56px] min-h-[56px] sm:min-w-[48px] sm:min-h-[48px] flex items-center justify-center",
                        "aria-label": "Previous week",
                        children: "‹"
                    }, void 0, false, {
                        fileName: "[project]/app/[user]/WeekEntriesClient.js",
                        lineNumber: 133,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: `/${encodeURIComponent(user)}?w=0`,
                        className: "px-2  sm:px-1 sm:py-1 rounded-full border text-sm text-gray-700 hover:bg-gray-100 min-h-[44px] flex items-center justify-center",
                        "aria-label": "Ga naar deze week",
                        children: [
                            "Vandaag:",
                            " ",
                            new Date().toLocaleDateString("nl-NL", {
                                weekday: "long",
                                month: "short",
                                day: "numeric"
                            })
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/[user]/WeekEntriesClient.js",
                        lineNumber: 136,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: `/${encodeURIComponent(user)}?w=${weekOffset + 1}`,
                        className: "rounded-full text-gray-600 hover:bg-gray-100 text-5xl sm:text-4xl min-w-[56px] min-h-[56px] sm:min-w-[48px] sm:min-h-[48px] flex items-center justify-center",
                        "aria-label": "Next week",
                        children: "›"
                    }, void 0, false, {
                        fileName: "[project]/app/[user]/WeekEntriesClient.js",
                        lineNumber: 144,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/[user]/WeekEntriesClient.js",
                lineNumber: 132,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full min-w-0 overflow-x-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "week grid grid-cols-7 gap-1 items-start",
                    children: [
                        "Maandag",
                        "Dinsdag",
                        "Woensdag",
                        "Donderdag",
                        "Vrijdag",
                        "Zaterdag",
                        "Zondag"
                    ].map((d, i)=>{
                        const dayDate = new Date(weekStart.getTime() + i * 24 * 60 * 60 * 1000);
                        const isToday = new Date().toDateString() === dayDate.toDateString();
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f5b$user$5d2f$DayClickableClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            dayDate: dayDate,
                            isToday: isToday,
                            dayLabel: d,
                            dayNumber: dayDate.getDate(),
                            hours: perDay[i],
                            money: perDayMoney[i],
                            expenses: perDayExpenses[i],
                            user: user,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "day-label text-[10px] tracking-wide text-gray-500 uppercase whitespace-nowrap w-full text-center mb-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sm:hidden",
                                            children: [
                                                "Ma",
                                                "Di",
                                                "Wo",
                                                "Do",
                                                "Vr",
                                                "Za",
                                                "Zo"
                                            ][i]
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                            lineNumber: 155,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "hidden sm:inline",
                                            children: d.slice(0, 3)
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                            lineNumber: 158,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                    lineNumber: 154,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `flex items-center justify-center w-8 h-8 rounded-full text-sm font-semibold mb-1 mx-auto ${isToday ? "bg-[#008eff] text-white" : "bg-gray-100 text-gray-900"}`,
                                    children: dayDate.getDate()
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                    lineNumber: 160,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "day-hours text-xs font-bold mb-0.5 tabular-nums min-h-4 w-full text-center",
                                    children: perDay[i] ? formatHoursHMM(perDay[i]) : "0:00"
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                    lineNumber: 163,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `day-expenses text-[10px] font-medium text-green-600 tabular-nums min-h-3.5 w-full text-center ${perDayExpenses[i] > 0 ? "" : "invisible"}`,
                                    children: perDayExpenses[i] > 0 ? formatMoney(perDayExpenses[i]) : "\u200B"
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                    lineNumber: 166,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `day-money text-[10px] font-medium text-gray-600 tabular-nums min-h-3.5 w-full text-center ${perDayMoney[i] > 0 ? "" : "invisible"}`,
                                    children: perDayMoney[i] > 0 ? formatMoney(perDayMoney[i]) : "\u200B"
                                }, void 0, false, {
                                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                    lineNumber: 169,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "sr-only",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sm:hidden",
                                            children: [
                                                "Ma",
                                                "Di",
                                                "Wo",
                                                "Do",
                                                "Vr",
                                                "Za",
                                                "Zo"
                                            ][i]
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                            lineNumber: 173,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "hidden sm:inline",
                                            children: d
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                            lineNumber: 176,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                    lineNumber: 172,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, d, true, {
                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                            lineNumber: 153,
                            columnNumber: 18
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                    lineNumber: 149,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/[user]/WeekEntriesClient.js",
                lineNumber: 148,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pt-2 px-4 border-t border-gray-200",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-sm font-semibold text-gray-700",
                            children: "Week Totaal"
                        }, void 0, false, {
                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                            lineNumber: 184,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-sm tabular-nums",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-600",
                                            children: "Tijd: "
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                            lineNumber: 187,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-medium",
                                            children: formatHoursHMM(weekTotalTime)
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                            lineNumber: 188,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                    lineNumber: 186,
                                    columnNumber: 13
                                }, this),
                                weekTotalMoney > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-sm tabular-nums",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-600",
                                            children: "Peso's: "
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                            lineNumber: 193,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-medium",
                                            children: formatMoney(weekTotalMoney)
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                            lineNumber: 194,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                    lineNumber: 192,
                                    columnNumber: 36
                                }, this),
                                weekTotalExpenses > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-sm tabular-nums",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-600",
                                            children: "Uitgaven: "
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                            lineNumber: 199,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-medium text-green-600",
                                            children: formatMoney(weekTotalExpenses)
                                        }, void 0, false, {
                                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                            lineNumber: 200,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                                    lineNumber: 198,
                                    columnNumber: 39
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/[user]/WeekEntriesClient.js",
                            lineNumber: 185,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/[user]/WeekEntriesClient.js",
                    lineNumber: 183,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/[user]/WeekEntriesClient.js",
                lineNumber: 182,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/[user]/WeekEntriesClient.js",
        lineNumber: 131,
        columnNumber: 10
    }, this);
}
_s(WeekEntriesClient, "Dpvb2zNoyS+RCZHNUAtD1iG3Li4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"]
    ];
});
_c = WeekEntriesClient;
var _c;
__turbopack_context__.k.register(_c, "WeekEntriesClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/[user]/ProjectsHydrator.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectsHydrator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/stores/useStore.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ProjectsHydrator(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "9c10cec0f5dc7bcb20229850f64a7d250e8bd51b0f520609867337950f42cf42") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9c10cec0f5dc7bcb20229850f64a7d250e8bd51b0f520609867337950f42cf42";
    }
    const { initialProjects } = t0;
    const hydrateProjects = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(_ProjectsHydratorUseStore);
    let t1;
    let t2;
    if ($[1] !== hydrateProjects || $[2] !== initialProjects) {
        t1 = ({
            "ProjectsHydrator[useEffect()]": ()=>{
                if (initialProjects) {
                    hydrateProjects(initialProjects);
                }
            }
        })["ProjectsHydrator[useEffect()]"];
        t2 = [
            initialProjects,
            hydrateProjects
        ];
        $[1] = hydrateProjects;
        $[2] = initialProjects;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    return null;
}
_s(ProjectsHydrator, "1u8uaQ0+WJ+05cydHEUVH4qIYmM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$useStore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"]
    ];
});
_c = ProjectsHydrator;
function _ProjectsHydratorUseStore(state) {
    return state.hydrateProjects;
}
var _c;
__turbopack_context__.k.register(_c, "ProjectsHydrator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_8dd04c61._.js.map